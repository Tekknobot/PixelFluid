using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace PixelOcean
{
    /// <summary>
    /// Autonomous 8x8 surfer. It rides to one edge, performs a turn trick,
    /// reverses direction, and rides the same wave back.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TinyWaveSurfer : MonoBehaviour
    {
        private enum RiderState
        {
            Riding,
            TurningTrick,
            SwitchingWave,
            Dead
        }

        [Header("Wave Selection")]
        [SerializeField, Min(1f)] private float secondsPerSimulation = 10f;
        [Tooltip("Random variation added to each surfer's layer-jump interval so they never transfer together.")]
        [SerializeField, Min(0f)] private float simulationTimeVariation = 3.5f;
        [SerializeField, Min(0.1f)] private float switchDuration = 0.9f;
        [SerializeField] private bool cycleContinuously = true;
        [Tooltip("Choose a different simulation layer instead of always moving to the next one.")]
        [SerializeField] private bool jumpToRandomWaveLayer = true;
        [Tooltip("Extra height used while jumping between simulation layers.")]
        [SerializeField, Range(0.1f, 3f)] private float layerJumpHeight = 0.55f;
        [SerializeField] private bool sortWavesBackToFront = true;
        [SerializeField, Min(0)] private int startingWaveIndex;

        [Header("Back-and-Forth Ride")]
        [SerializeField, Min(0.1f)] private float horizontalRideSpeed = 1.2f;
        [SerializeField, Range(0.02f, 0.35f)] private float edgePadding = 0.12f;
        [SerializeField] private bool startMovingRight = true;
        [SerializeField, Min(0f)] private float surfaceOffset;
        [SerializeField, Range(1f, 30f)] private float surfaceFollow = 16f;
        [SerializeField, Range(0f, 2f)] private float waveVelocityInfluence = 0.22f;

        [Header("Edge Turn Trick")]
        [SerializeField, Range(0.1f, 2f)] private float turnJumpHeight = 0.26f;
        [SerializeField, Range(0.2f, 1.5f)] private float turnTrickDuration = 0.38f;
        [SerializeField, Range(90f, 1080f)] private float turnSpinDegrees = 360f;
        [SerializeField, Range(0f, 1f)] private float flipChance = 0.45f;

        [Header("Player Control")]
        [SerializeField] private bool playerControlled;
        [SerializeField, Min(0.25f)] private float playerScrollSpeed = 2.4f;
        [SerializeField, Range(1f, 4f)] private float playerBoostMultiplier = 1.75f;
        [Tooltip("World-space padding that keeps the surfer clear of the camera's left and right screen edges.")]
        [SerializeField, Range(0f, 1f)] private float playerCameraEdgePadding = 0.12f;
        [SerializeField] private bool lockPlayerToScreenX = false;
        [SerializeField] private float playerScreenX = 0f;

        [Header("Player Movement Feel")]
        [Tooltip("How quickly movement builds toward full speed.")]
        [SerializeField, Min(0.1f)] private float playerAcceleration = 7.5f;
        [Tooltip("How quickly the surfer slows when movement is released.")]
        [SerializeField, Min(0.1f)] private float playerDeceleration = 10f;
        [Tooltip("Analog-stick dead zone.")]
        [SerializeField, Range(0f, 0.5f)] private float gamepadDeadZone = 0.18f;
        [Tooltip("Allows horizontal steering while airborne.")]
        [SerializeField, Range(0f, 1f)] private float airControl = 0.45f;

        [Header("Player Air Tricks")]
        [Tooltip("Maximum extra rotation controlled with the right stick while airborne.")]
        [SerializeField, Range(0f, 1080f)] private float playerAirTrickDegrees = 540f;
        [Tooltip("Smooths the jump arc at takeoff and landing.")]
        [SerializeField, Range(0.1f, 3f)] private float playerJumpArcPower = 1.35f;

        [Header("Random Initial Ocean Spawn")]
        [Tooltip("When enabled, the player surfer starts on a random horizontal section and random wave layer after the endless ocean has finished building.")]
        [SerializeField] private bool randomizeInitialOceanSpawn;
        [Tooltip("Keeps the initial position away from the far outside edges of the three-section ocean.")]
        [SerializeField, Range(0f, 0.45f)] private float randomSpawnEdgePadding = 0.08f;
        [Tooltip("Minimum world-space clearance from sharks and giant squids when choosing the initial player spawn.")]
        [SerializeField, Min(0f)] private float enemySafeSpawnRadius = 3.5f;
        [Tooltip("How many random ocean positions are tested before using the safest position found.")]
        [SerializeField, Range(1, 100)] private int safeSpawnAttempts = 40;

        [Header("Shark Death Response")]
        [SerializeField, Min(0.25f)] private float deathDuration = 1.6f;
        [SerializeField, Min(0f)] private float deathKnockUp = 0.7f;
        [SerializeField, Min(0f)] private float deathSinkSpeed = 0.65f;
        [SerializeField, Range(90f, 1080f)] private float deathSpinSpeed = 520f;
        [SerializeField] private bool respawnAfterDeath = true;
        [SerializeField, Min(0f)] private float respawnDelay = 0.7f;

        [Header("Death Blood Particles")]
        [SerializeField] private bool emitBloodOnDeath = true;
        [SerializeField, Range(4, 80)] private int deathBloodParticleCount = 32;
        [SerializeField, Min(0.05f)] private float deathBloodLifetime = 2.35f;
        [SerializeField, Min(0f)] private float deathBloodMinSpeed = 0.12f;
        [SerializeField, Min(0f)] private float deathBloodMaxSpeed = 0.48f;
        [SerializeField, Range(0.005f, 0.2f)] private float deathBloodMinSize = 0.020f;
        [SerializeField, Range(0.005f, 0.25f)] private float deathBloodMaxSize = 0.020f;
        [SerializeField] private float deathBloodGravity = 0.01f;
        [SerializeField] private Vector2 deathBloodOffset = new(0f, 0.08f);
        [SerializeField, ColorUsage(true, true)] private Color deathBloodColor = new(0.9f, 0f, 0f, 0.7f);

        [Header("Health and Hit Reaction")]
        [SerializeField, Min(1)] private int maximumHealth = 3;
        [SerializeField, Min(1)] private int sharkHitDamage = 1;
        [SerializeField, Min(0f)] private float hitInvulnerability = 0.8f;
        [SerializeField, Min(0.02f)] private float hitFlashDuration = 0.34f;
        [SerializeField, Min(0.01f)] private float hitFlashInterval = 0.055f;
        [SerializeField, Min(0f)] private float hitBumpDistance = 0.24f;
        [SerializeField, Min(0f)] private float hitBumpHeight = 0.10f;
        [SerializeField] private Color hitFlashColor = new(1f, 0.08f, 0.08f, 1f);
        [SerializeField] private Color heartPickupFlashColor = new(0.45f, 1f, 0.58f, 1f);
        [SerializeField, Min(0.05f)] private float heartPickupReactionDuration = 0.42f;

        [Header("Surfer Sprite")]
        [SerializeField] private string surferSpriteResource = "Surfers/chuck";
        [SerializeField, Min(0.05f)] private float spriteWorldScale = 0.65f;
        [SerializeField] private int sortingOrder = 1;
        [Tooltip("Local SpriteRenderer order inside the surfer render queue. Kept below lane creatures so a shark in front can cover this surfer.")]
        [SerializeField] private int surferWithinWaveSortingOrder = 0;

        [Header("Long Idle Animation")]
        [SerializeField] private bool playProneAfterLongIdle = true;
        [SerializeField, Min(0.5f)] private float proneIdleDelay = 7f;

        [Header("Speech Bubbles")]
        [SerializeField] private bool enableSpeechBubbles = false;
        [SerializeField, Min(0.5f)] private float idleSpeechDelay = 4.5f;
        [SerializeField, Min(1f)] private float idleSpeechCooldown = 10f;
        [SerializeField, Min(0.25f)] private float sharkSpeechRange = 2.25f;
        [SerializeField, Min(0.1f)] private float sharkCheckInterval = 0.2f;
        [SerializeField, Min(1f)] private float sharkSpeechCooldown = 6f;
        [SerializeField] private string[] idleSpeechLines =
        {
            "JUST BREATHE.",
            "THE OCEAN REMEMBERS.",
            "QUIET OUT HERE.",
            "ONE MORE WAVE.",
            "THE TIDE IS CHANGING.",
            "KEEP PADDLING.",
            "JUST RIDE.",
            "DON'T THINK.",
            "THIS FEELS DIFFERENT.",
            "I'VE BEEN HERE BEFORE.",
            "WHERE DID EVERYONE GO?",
            "THE SEA NEVER SLEEPS.",
            "WAIT FOR THE SET.",
            "THE WIND JUST TURNED.",
            "TOO QUIET.",
            "STAY LOOSE.",
            "FIND THE LINE.",
            "LET IT CARRY ME.",
            "NOT A BAD PLACE TO BE.",
            "THE HORIZON KEEPS MOVING.",
            "I COULD STAY OUT HERE.",
            "SOMETHING'S WATCHING.",
            "THE WATER FEELS COLD.",
            "NO RUSH.",
            "LISTEN TO THE WATER.",
            "HERE COMES ANOTHER ONE.",
            "KEEP YOUR BALANCE.",
            "DON'T LOOK DOWN.",
            "THE CURRENT IS STRONG.",
            "MAYBE THIS IS ENOUGH.",
            "I NEEDED THIS.",
            "THE SHORE FEELS FAR AWAY.",
            "JUST ME AND THE SWELL.",
            "THE SKY LOOKS ENDLESS.",
            "RIDE IT CLEAN.",
            "WAIT... NOW.",
            "EVERY WAVE IS DIFFERENT.",
            "STILL HERE.",
            "KEEP MOVING FORWARD.",
            "THE NEXT ONE'S MINE."
        };
        [SerializeField] private string[] sharkSpeechLines =
        {
            "THAT FIN IS CLOSE.",
            "NOT ALONE OUT HERE.",
            "EASY... EASY...",
            "I SHOULD MOVE.",
            "NOT NOW.",
            "I SAW THAT.",
            "TOO CLOSE.",
            "STAY CALM.",
            "DON'T PANIC.",
            "KEEP MOVING.",
            "PLEASE LEAVE.",
            "I'M NOT FOOD.",
            "JUST PASS BY...",
            "NO SUDDEN MOVES.",
            "THAT'S A BIG ONE.",
            "WRONG WAVE, FRIEND.",
            "KEEP YOUR DISTANCE.",
            "DON'T TURN TOWARD ME.",
            "I KNOW YOU'RE THERE.",
            "THIS IS YOUR OCEAN.",
            "WE CAN SHARE, RIGHT?",
            "JUST KEEP SWIMMING.",
            "WHY IS IT CIRCLING?",
            "I DON'T LIKE THIS.",
            "STAY ON THE BOARD.",
            "DON'T FALL NOW.",
            "MOVE. MOVE. MOVE.",
            "THE SHORE IS THAT WAY.",
            "YOU DIDN'T SEE ME.",
            "PLEASE BE A DOLPHIN."
        };

        [Header("Single-Frame Water Motion")]
        [SerializeField, Range(0f, 0.12f)] private float idleBobHeight = 0.018f;
        [SerializeField, Range(0.1f, 8f)] private float idleBobFrequency = 2.4f;
        [SerializeField, Range(0f, 12f)] private float directionalLean = 3.5f;
        [SerializeField, Range(0f, 0.12f)] private float stanceSquash = 0.035f;
        [SerializeField] private Color bodyColor = new(0.12f, 0.08f, 0.06f, 1f);
        [SerializeField] private Color shirtColor = new(0.95f, 0.32f, 0.12f, 1f);
        [SerializeField] private Color boardColor = new(1f, 0.88f, 0.24f, 1f);

        private Animator surferAnimator;

        private static readonly int IdleStateHash =
            Animator.StringToHash("Idle");
        private static readonly int MoveStateHash =
            Animator.StringToHash("chuck_move");
        private static readonly int DeathStateHash =
            Animator.StringToHash("chuck_death");
        private static readonly int ProneStateHash =
            Animator.StringToHash("chuck_prone");

        private int currentAnimationStateHash;
        private float playerIdleTimer;
        private SurferSpeechBubble speechBubble;
        private float nextIdleSpeechTime;
        private float nextSharkSpeechTime;
        private float nextSharkCheckTime;
        private bool sharkWasNearby;

        private readonly List<PixelWaterGPU> simulations = new();
        private PixelWaterGPU currentWave;
        private SpriteRenderer spriteRenderer;
        private Sprite runtimeSprite;
        private Texture2D runtimeTexture;
        private Material originalSpriteMaterial;
        private Material surferWaveMaterial;
        private ParticleSystem deathBloodParticles;
        private Material deathBloodMaterial;
        private AudioSource deathAudioSource;
        [Header("Reaction Audio")]
        [SerializeField] private AudioClip humanDeathClip;
        [SerializeField] private AudioClip maleHurtClip;
        [SerializeField] private AudioClip healthUpClip;
        [SerializeField, Range(0f, 1f)] private float hurtSoundVolume = 1f;
        [SerializeField, Range(0f, 1f)] private float healthUpSoundVolume = 1f;
        private int lastWaveRenderQueue = -1;

        private RiderState state;
        private int waveIndex;
        private float waveTimer;
        private float currentSimulationDuration;
        private float stateTimer;
        private float direction = 1f;
        private float localRideX;
        private float airStartY;
        private float renderDepth;
        private bool flipTrick;
        private Vector3 switchStart;
        private Vector3 switchTarget;
        private bool previousJumpHeld;
        private bool previousLayerUpHeld;
        private bool previousLayerDownHeld;
        private bool layerSwitchInputLocked;
        private float playerHorizontalVelocity;
        private float playerTrickInput;
        private float deathTimer;
        private float respawnTimer;
        private Vector2 deathVelocity;
        private Vector3 livingScale;
        private Color livingColor = Color.white;
        private int currentHealth;
        private float invulnerableUntil;
        private float spriteReactionTimer;
        private float spriteReactionDuration;
        private float spriteFlashInterval;
        private Color spriteReactionColor = Color.white;
        private SurferHealthBar healthBar;
        private readonly Queue<Sprite> throwableItems = new Queue<Sprite>();
        private bool previousAttackHeld;

        public int CurrentWaveIndex => waveIndex;
        public PixelWaterGPU CurrentWave => currentWave;
        public float TravelDirection => direction;
        public bool IsDead => state == RiderState.Dead;
        public bool IsPlayerControlled => playerControlled;
        public int CurrentHealth => currentHealth;
        public int MaximumHealth => Mathf.Max(1, maximumHealth);
        public bool IsSwitchingWave => state == RiderState.SwitchingWave;
        // Kept for compatibility with any UI or scripts that previously displayed cans.
        // It now represents every collected throwable ocean item.
        public int SodaCanCount => throwableItems.Count;
        public int ThrowableItemCount => throwableItems.Count;

        [Tooltip("Enable this when the original sprite artwork faces right.")]
        [SerializeField] private bool spriteFacesRight = true;

        private void ApplyFacing(float xScale, float yScale)
        {
            bool movingRight = direction > 0f;

            if (spriteRenderer != null)
            {
                spriteRenderer.flipX = spriteFacesRight
                    ? !movingRight
                    : movingRight;
            }

            transform.localScale = new Vector3(
                Mathf.Abs(xScale),
                Mathf.Abs(yScale),
                1f);
        }

        private void Awake()
        {
            deathAudioSource = GetComponent<AudioSource>();
            if (deathAudioSource == null)
                deathAudioSource = gameObject.AddComponent<AudioSource>();

            deathAudioSource.playOnAwake = false;
            deathAudioSource.loop = false;
            deathAudioSource.spatialBlend = 0f;

            if (humanDeathClip == null)
                humanDeathClip = Resources.Load<AudioClip>("Audio/SFX/human_death");
            if (maleHurtClip == null)
                maleHurtClip = Resources.Load<AudioClip>("Audio/SFX/male_hurt");
            if (healthUpClip == null)
                healthUpClip = Resources.Load<AudioClip>("Audio/SFX/health_up");
            EnsurePixelSprite();
            EnsureSurferAnimator();
            EnsureSharkHitCollider();
            EnsureSpeechBubble();
            EnsureHealthBar();
            if (FindFirstObjectByType<SodaCanSpawner>() == null) new GameObject("Soda Can Spawner").AddComponent<SodaCanSpawner>();
            currentHealth = Mathf.Max(1, maximumHealth);
            healthBar?.SetHealth(currentHealth, MaximumHealth);

            livingScale = transform.localScale;

            if (spriteRenderer != null)
                livingColor = spriteRenderer.color;

            RefreshWaveList();

            direction =
                startMovingRight ? 1f : -1f;

            PickWave(startingWaveIndex, true);

            ApplyCurrentWaveSorting(true);

            ScheduleNextLayerJump(0f);
        }

        private IEnumerator Start()
        {
            if (!randomizeInitialOceanSpawn)
                yield break;

            // EndlessWaveSections builds after the independent vertical wave layers,
            // so wait until all three horizontal ocean sections are available.
            float timeout = 5f;
            while (timeout > 0f)
            {
                EndlessWaveSections endless = EndlessWaveSections.Instance;
                if (endless != null && endless.IsReady)
                    break;

                timeout -= Time.unscaledDeltaTime;
                yield return null;
            }

            // Population spawners also wait for the ocean. Give them two frames to
            // create sharks and squids before selecting a safe player position.
            yield return null;
            yield return null;

            SpawnAtRandomOceanPosition();
        }

        private void LateUpdate()
        {
            UpdateSpriteReaction(Time.deltaTime);

            if (speechBubble != null)
                speechBubble.RefreshSorting();

            // Re-apply after movement/animation so changing wave layers immediately
            // changes the surfer's transparent queue as well.
            ApplyCurrentWaveSorting();
        }

        private void OnDestroy()
        {
            if (spriteRenderer != null && originalSpriteMaterial != null)
                spriteRenderer.sharedMaterial = originalSpriteMaterial;

            if (surferWaveMaterial != null)
                Destroy(surferWaveMaterial);

            if (deathBloodMaterial != null)
                Destroy(deathBloodMaterial);

            if (runtimeSprite != null) Destroy(runtimeSprite);
            if (runtimeTexture != null) Destroy(runtimeTexture);
        }

        private void ApplyCurrentWaveSorting(bool force = false)
        {
            if (spriteRenderer == null)
                return;

            if (currentWave == null)
            {
                if (simulations.Count == 0)
                    RefreshWaveList();

                if (simulations.Count == 0)
                    return;

                waveIndex = Mathf.Clamp(
                    waveIndex,
                    0,
                    simulations.Count - 1);

                currentWave = simulations[waveIndex];
            }

            // Queue layout uses four slots per wave depth:
            // water = N, surfer = N + 1, shark lane = N + 2,
            // next foreground water = N + 4.
            // This guarantees a surfer is above its own water, behind a shark
            // in the lane immediately in front, and in front of a shark in the
            // lane immediately behind.
            int waterQueue =
                currentWave.GetWaveLayerRenderQueue();

            int surferQueue = Mathf.Clamp(
                waterQueue + 1,
                2501,
                4999);

            if (surferWaveMaterial == null)
            {
                originalSpriteMaterial =
                    spriteRenderer.sharedMaterial;

                Material source = originalSpriteMaterial;

                if (source == null)
                {
                    Shader spriteShader =
                        Shader.Find("Sprites/Default");

                    if (spriteShader == null)
                    {
                        Debug.LogWarning(
                            "Sprites/Default shader could not be found.",
                            this);

                        return;
                    }

                    source = new Material(spriteShader);
                }

                surferWaveMaterial = new Material(source)
                {
                    name = $"{name} Dynamic Wave Sorting",
                    hideFlags = HideFlags.HideAndDontSave
                };

                spriteRenderer.sharedMaterial =
                    surferWaveMaterial;

                force = true;
            }

            if (force ||
                surferQueue != lastWaveRenderQueue)
            {
                surferWaveMaterial.renderQueue =
                    surferQueue;

                lastWaveRenderQueue =
                    surferQueue;
            }

            spriteRenderer.sortingOrder =
                surferWithinWaveSortingOrder;
        }

        private void EnsureSharkHitCollider()
        {
            Collider2D collider = GetComponent<Collider2D>();
            if (collider == null)
            {
                CircleCollider2D circle = gameObject.AddComponent<CircleCollider2D>();
                circle.isTrigger = true;
                circle.radius = 0.28f;
                collider = circle;
            }

            Rigidbody2D body = GetComponent<Rigidbody2D>();
            if (body == null)
                body = gameObject.AddComponent<Rigidbody2D>();
            body.bodyType = RigidbodyType2D.Kinematic;
            body.gravityScale = 0f;
            body.freezeRotation = true;
        }


        private void EnsureHealthBar()
        {
            healthBar = GetComponent<SurferHealthBar>();
            if (healthBar == null)
                healthBar = gameObject.AddComponent<SurferHealthBar>();
        }

        public bool TakeSharkHit(Vector2 sharkPosition)
        {
            if (state == RiderState.Dead || Time.time < invulnerableUntil)
                return false;

            invulnerableUntil = Time.time + hitInvulnerability;
            currentHealth = Mathf.Max(0, currentHealth - Mathf.Max(1, sharkHitDamage));
            healthBar?.SetHealth(currentHealth, MaximumHealth);

            float away = transform.position.x >= sharkPosition.x ? 1f : -1f;
            transform.position += new Vector3(away * hitBumpDistance, hitBumpHeight, 0f);
            localRideX = transform.position.x;
            // A strong red-only flash clearly communicates damage without washing the sprite white.
            BeginSpriteReaction(hitFlashColor, hitFlashDuration, hitFlashInterval);
            if (maleHurtClip != null && deathAudioSource != null)
                deathAudioSource.PlayOneShot(maleHurtClip, hurtSoundVolume);
            if (speechBubble != null) speechBubble.HideImmediate();

            if (currentHealth <= 0)
                return DieFromShark(sharkPosition);

            return true;
        }


        /// <summary>
        /// Plays one beat of the giant squid's combo. Every beat produces its own
        /// bump, red flash and hurt sound, but only the beat with applyDamage=true
        /// removes health. This intentionally bypasses the normal shark-hit
        /// invulnerability gate for the reaction only.
        /// </summary>
        public bool TakeSquidComboBeat(Vector2 squidPosition, bool applyDamage)
        {
            if (state == RiderState.Dead)
                return false;

            if (applyDamage)
            {
                currentHealth = Mathf.Max(0, currentHealth - Mathf.Max(1, sharkHitDamage));
                healthBar?.SetHealth(currentHealth, MaximumHealth);

                // Preserve normal protection from unrelated hazards after the
                // combo begins, without suppressing the squid's later visual beats.
                invulnerableUntil = Mathf.Max(invulnerableUntil, Time.time + hitInvulnerability);
            }

            float away = transform.position.x >= squidPosition.x ? 1f : -1f;
            float beatBumpX = hitBumpDistance * (applyDamage ? 0.72f : 0.34f);
            float beatBumpY = hitBumpHeight * (applyDamage ? 0.72f : 0.38f);
            transform.position += new Vector3(away * beatBumpX, beatBumpY, 0f);
            localRideX = transform.position.x;

            // Restart a short reaction on every combo beat instead of waiting for
            // the normal hurt cooldown or the previous flash to finish.
            BeginSpriteReaction(hitFlashColor, 0.14f, 0.035f);
            if (maleHurtClip != null && deathAudioSource != null)
                deathAudioSource.PlayOneShot(maleHurtClip, hurtSoundVolume);
            if (speechBubble != null)
                speechBubble.HideImmediate();

            if (applyDamage && currentHealth <= 0)
                return DieFromShark(squidPosition);

            return true;
        }


        public bool CollectSodaCan()
        {
            Sprite canSprite = Resources.Load<Sprite>("Items/soda_can");
            return CollectThrowableItem(canSprite);
        }

        /// <summary>
        /// Adds any collected ocean sprite to the shared throwable inventory.
        /// Each pickup retains its own artwork and is thrown later in pickup order.
        /// </summary>
        public bool CollectThrowableItem(Sprite itemSprite)
        {
            if (IsDead || itemSprite == null)
                return false;

            throwableItems.Enqueue(itemSprite);
            BeginSpriteReaction(new Color(0.35f, 0.85f, 1f, 1f), 0.35f, 0.06f);
            transform.localScale = livingScale * 1.14f;
            return true;
        }

        private void ThrowSodaCan(bool aimAtUfo)
        {
            if (throwableItems.Count <= 0 || IsDead || state != RiderState.Riding) return;

            Transform nearest = null;
            float best = float.MaxValue;

            // Holding Up while pressing Action reserves the throw for the UFO.
            // This prevents a nearby shark from stealing the upward shot.
            if (aimAtUfo)
            {
                AlienUfoController ufo = FindFirstObjectByType<AlienUfoController>();
                if (ufo != null && ufo.CanBeHit)
                    nearest = ufo.transform;
                else
                    return; // Do not spend a can when there is no hittable UFO.
            }
            else
            {
                foreach (SharkLaneSwimmer shark in FindObjectsByType<SharkLaneSwimmer>(FindObjectsSortMode.None))
                {
                    if (shark == null) continue;
                    float d = Vector2.Distance(transform.position, shark.transform.position);
                    if (d < best) { best = d; nearest = shark.transform; }
                }

                foreach (GiantSquidLaneSwimmer squid in FindObjectsByType<GiantSquidLaneSwimmer>(FindObjectsSortMode.None))
                {
                    if (squid == null) continue;
                    float d = Vector2.Distance(transform.position, squid.transform.position);
                    if (d < best) { best = d; nearest = squid.transform; }
                }
            }

            Sprite sprite = throwableItems.Dequeue();

            GameObject projectile = new GameObject(aimAtUfo ? "UFO Thrown Item Shot" : $"Thrown Ocean Item - {sprite.name}");
            projectile.AddComponent<SpriteRenderer>().sortingOrder = sortingOrder + 20;
            projectile.AddComponent<CircleCollider2D>();
            projectile.AddComponent<Rigidbody2D>();
            SodaCanProjectile can = projectile.AddComponent<SodaCanProjectile>();
            can.Launch(
                (Vector2)transform.position + new Vector2(direction * .22f, .22f),
                nearest,
                sprite,
                direction,
                aimAtUfo);
        }

        private void PerformAction(bool aimAtUfo)
        {
            // Action alone throws the next stored ocean item toward sea hazards.
            // Up + Action fires it into the sky at the UFO. Ocean props collect automatically.
            ThrowSodaCan(aimAtUfo);
        }

        private static bool ReadAttackInput()
        {
#if ENABLE_INPUT_SYSTEM
            bool keyboard = Keyboard.current != null &&
                (Keyboard.current.fKey.isPressed || Keyboard.current.xKey.isPressed);
            bool gamepad = Gamepad.current != null &&
                Gamepad.current.buttonWest.isPressed;
            if (keyboard || gamepad)
                return true;
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKey(KeyCode.F) || Input.GetKey(KeyCode.X);
#else
            return false;
#endif
        }

        public bool HealFromHeart(int amount = 1)
        {
            if (state == RiderState.Dead || currentHealth >= MaximumHealth)
                return false;

            currentHealth = Mathf.Min(MaximumHealth, currentHealth + Mathf.Max(1, amount));
            healthBar?.SetHealth(currentHealth, MaximumHealth);
            BeginSpriteReaction(heartPickupFlashColor, heartPickupReactionDuration, 0.07f);
            if (healthUpClip != null && deathAudioSource != null)
                deathAudioSource.PlayOneShot(healthUpClip, healthUpSoundVolume);
            transform.localScale = livingScale * 1.16f;
            return true;
        }

        private void BeginSpriteReaction(Color colour, float duration, float interval)
        {
            spriteReactionColor = colour;
            spriteReactionDuration = Mathf.Max(0.02f, duration);
            spriteReactionTimer = spriteReactionDuration;
            spriteFlashInterval = Mathf.Max(0.02f, interval);
        }

        private void UpdateSpriteReaction(float dt)
        {
            if (spriteRenderer == null || state == RiderState.Dead)
                return;

            if (spriteReactionTimer <= 0f)
            {
                spriteRenderer.color = livingColor;
                transform.localScale = Vector3.Lerp(transform.localScale, livingScale, 1f - Mathf.Exp(-18f * dt));
                return;
            }

            spriteReactionTimer = Mathf.Max(0f, spriteReactionTimer - dt);
            bool flashOn = Mathf.FloorToInt(spriteReactionTimer / spriteFlashInterval) % 2 == 0;
            spriteRenderer.color = flashOn ? spriteReactionColor : livingColor;
            float t = 1f - spriteReactionTimer / spriteReactionDuration;
            float pulse = 1f + Mathf.Sin(t * Mathf.PI) * 0.16f;
            transform.localScale = livingScale * pulse;
        }

        private void EnsureSpeechBubble()
        {
            if (!enableSpeechBubbles) return;
            speechBubble = GetComponent<SurferSpeechBubble>();
            if (speechBubble == null)
                speechBubble = gameObject.AddComponent<SurferSpeechBubble>();
            nextIdleSpeechTime = Time.time + idleSpeechDelay;
        }

        private void UpdateSpeechBubbles()
        {
            if (!enableSpeechBubbles || speechBubble == null)
                return;

            // Dialogue is only allowed while the surfer is steadily riding.
            // Hide any active bubble immediately during tricks/jumps, wave
            // crossings, or death so it never follows the surfer through the air.
            if (state != RiderState.Riding)
            {
                speechBubble.HideImmediate();
                return;
            }

            if (Time.time >= nextSharkCheckTime)
            {
                nextSharkCheckTime = Time.time + sharkCheckInterval;
                bool sharkNearby = false;
                float closestDistance = sharkSpeechRange;
                foreach (SharkLaneSwimmer shark in FindObjectsByType<SharkLaneSwimmer>(FindObjectsSortMode.None))
                {
                    if (shark == null || !shark.isActiveAndEnabled) continue;
                    float distance = Vector2.Distance(transform.position, shark.transform.position);
                    if (distance <= closestDistance)
                    {
                        closestDistance = distance;
                        sharkNearby = true;
                    }
                }

                if (sharkNearby && (!sharkWasNearby || Time.time >= nextSharkSpeechTime))
                {
                    ShowRandomSpeech(sharkSpeechLines, 2.2f);
                    nextSharkSpeechTime = Time.time + sharkSpeechCooldown;
                    nextIdleSpeechTime = Time.time + idleSpeechCooldown;
                }
                sharkWasNearby = sharkNearby;
            }

            if (playerControlled && playerIdleTimer >= idleSpeechDelay &&
                Time.time >= nextIdleSpeechTime && !sharkWasNearby)
            {
                ShowRandomSpeech(idleSpeechLines, 2.8f);
                nextIdleSpeechTime = Time.time + idleSpeechCooldown;
            }
        }

        private void ShowRandomSpeech(string[] lines, float duration)
        {
            if (lines == null || lines.Length == 0 || speechBubble == null) return;
            string line = lines[Random.Range(0, lines.Length)];
            if (!string.IsNullOrWhiteSpace(line))
                speechBubble.Show(line, duration);
        }

        private void EnsureSurferAnimator()
        {
            surferAnimator = GetComponent<Animator>();

            if (surferAnimator == null)
                surferAnimator = gameObject.AddComponent<Animator>();

            RuntimeAnimatorController controller =
                Resources.Load<RuntimeAnimatorController>("Animations/chuck");

            if (controller == null)
            {
                Debug.LogWarning(
                    "TinyWaveSurfer could not load Resources/Animations/chuck.controller.",
                    this);
                surferAnimator.enabled = false;
                return;
            }

            surferAnimator.runtimeAnimatorController = controller;
            surferAnimator.applyRootMotion = false;
            surferAnimator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            surferAnimator.enabled = true;

            currentAnimationStateHash = 0;
            playerIdleTimer = 0f;
            UpdateAnimation(false, true);
        }

        private void UpdateAnimation(bool moving, bool force = false)
        {
            if (surferAnimator == null ||
                !surferAnimator.enabled ||
                surferAnimator.runtimeAnimatorController == null ||
                state == RiderState.Dead)
            {
                return;
            }

            bool useProne =
                playerControlled &&
                playProneAfterLongIdle &&
                !moving &&
                state == RiderState.Riding &&
                playerIdleTimer >= proneIdleDelay;

            int desiredStateHash = useProne
                ? ProneStateHash
                : moving ? MoveStateHash : IdleStateHash;

            if (!force && currentAnimationStateHash == desiredStateHash)
                return;

            currentAnimationStateHash = desiredStateHash;
            surferAnimator.Play(desiredStateHash, 0, 0f);
        }

        private void PlayDeathAnimation()
        {
            if (surferAnimator == null ||
                !surferAnimator.enabled ||
                surferAnimator.runtimeAnimatorController == null)
            {
                return;
            }

            currentAnimationStateHash = DeathStateHash;
            surferAnimator.Play(DeathStateHash, 0, 0f);
        }

        public bool DieFromShark(Vector2 sharkPosition)
        {
            if (state == RiderState.Dead)
                return false;

            state = RiderState.Dead;
            playerIdleTimer = 0f;
            if (speechBubble != null) speechBubble.HideImmediate();
            PlayDeathAnimation();
            EmitDeathBlood();
            if (humanDeathClip != null && deathAudioSource != null)
                deathAudioSource.PlayOneShot(humanDeathClip);
            deathTimer = 0f;
            respawnTimer = 0f;
            float away = transform.position.x >= sharkPosition.x ? 1f : -1f;
            deathVelocity = new Vector2(away * 0.8f, deathKnockUp);
            livingScale = transform.localScale;
            if (spriteRenderer != null)
                livingColor = spriteRenderer.color;

            Collider2D collider = GetComponent<Collider2D>();
            if (collider != null) collider.enabled = false;
            return true;
        }

        public bool DieFromAbduction(Vector2 ufoPosition)
        {
            if (state == RiderState.Dead)
                return false;

            state = RiderState.Dead;
            playerIdleTimer = 0f;
            if (speechBubble != null) speechBubble.HideImmediate();
            PlayDeathAnimation();
            if (humanDeathClip != null && deathAudioSource != null)
                deathAudioSource.PlayOneShot(humanDeathClip);
            deathTimer = 0f;
            respawnTimer = 0f;
            deathVelocity = new Vector2((ufoPosition.x - transform.position.x) * 0.35f, deathKnockUp * 1.55f);
            livingScale = transform.localScale;
            if (spriteRenderer != null)
                livingColor = spriteRenderer.color;

            Collider2D collider = GetComponent<Collider2D>();
            if (collider != null) collider.enabled = false;
            return true;
        }

        private void EmitDeathBlood()
        {
            if (!emitBloodOnDeath || deathBloodParticleCount <= 0)
                return;

            EnsureDeathBloodEmitter();

            if (deathBloodParticles == null)
                return;

            deathBloodParticles.transform.position =
                transform.position + (Vector3)deathBloodOffset;

            float minSpeed = Mathf.Min(
                deathBloodMinSpeed,
                deathBloodMaxSpeed);

            float maxSpeed = Mathf.Max(
                deathBloodMinSpeed,
                deathBloodMaxSpeed);

            float minSize = Mathf.Min(
                deathBloodMinSize,
                deathBloodMaxSize);

            float maxSize = Mathf.Max(
                deathBloodMinSize,
                deathBloodMaxSize);

            // Use ordinary non-HDR red.
            Color bloodRed = deathBloodColor;

            ParticleSystem.EmitParams emit =
                new ParticleSystem.EmitParams
                {
                    startColor = bloodRed,
                    startLifetime = deathBloodLifetime
                };

            for (int i = 0; i < deathBloodParticleCount; i++)
            {
                float angle =
                    Random.Range(0f, 360f) *
                    Mathf.Deg2Rad;

                float speed =
                    Random.Range(minSpeed, maxSpeed);

                emit.velocity = new Vector3(
                    Mathf.Cos(angle) * speed,
                    Mathf.Sin(angle) * speed,
                    Random.Range(-0.03f, 0.03f));

                emit.startSize =
                    Random.Range(minSize, maxSize);

                deathBloodParticles.Emit(emit, 1);
            }
        }

        private void EnsureDeathBloodEmitter()
        {
            if (deathBloodParticles != null)
                return;

            GameObject emitterObject =
                new GameObject("Death Blood Particles");

            emitterObject.transform.SetParent(null);
            emitterObject.transform.position =
                transform.position;

            deathBloodParticles =
                emitterObject.AddComponent<ParticleSystem>();

            Color bloodRed =
                deathBloodColor;

            // Main particle settings.
            ParticleSystem.MainModule main =
                deathBloodParticles.main;

            main.loop = false;
            main.playOnAwake = false;
            main.simulationSpace =
                ParticleSystemSimulationSpace.World;

            main.startLifetime =
                deathBloodLifetime;

            main.startSpeed = 0f;

            main.startSize =
                new ParticleSystem.MinMaxCurve(
                    deathBloodMinSize,
                    deathBloodMaxSize);

            main.startColor = bloodRed;
            main.gravityModifier = deathBloodGravity;

            main.maxParticles =
                Mathf.Max(
                    64,
                    deathBloodParticleCount * 3);

            main.stopAction =
                ParticleSystemStopAction.None;

            // Particles are emitted manually.
            ParticleSystem.EmissionModule emission =
                deathBloodParticles.emission;

            emission.enabled = false;

            ParticleSystem.ShapeModule shape =
                deathBloodParticles.shape;

            shape.enabled = false;

            // Keep their launch velocity simple.
            ParticleSystem.LimitVelocityOverLifetimeModule limitVelocity =
                deathBloodParticles.limitVelocityOverLifetime;

            limitVelocity.enabled = false;

            // Fade from fully visible red to transparent red.
            ParticleSystem.ColorOverLifetimeModule colourOverLifetime =
                deathBloodParticles.colorOverLifetime;

            colourOverLifetime.enabled = true;

            Gradient fadeGradient = new Gradient();

            fadeGradient.SetKeys(
                new[]
                {
                    new GradientColorKey(bloodRed, 0f),
                    new GradientColorKey(bloodRed, 1f)
                },
                new[]
                {
                    new GradientAlphaKey(1f, 0f),
                    new GradientAlphaKey(1f, 0.15f),
                    new GradientAlphaKey(0.65f, 0.45f),
                    new GradientAlphaKey(0.25f, 0.75f),
                    new GradientAlphaKey(0f, 1f)
                });

            colourOverLifetime.color =
                new ParticleSystem.MinMaxGradient(
                    fadeGradient);

            // Shrink the particles while they fade.
            ParticleSystem.SizeOverLifetimeModule sizeOverLifetime =
                deathBloodParticles.sizeOverLifetime;

            sizeOverLifetime.enabled = true;

            AnimationCurve sizeCurve =
                new AnimationCurve(
                    new Keyframe(0f, 1f),
                    new Keyframe(0.65f, 0.85f),
                    new Keyframe(1f, 0f));

            sizeOverLifetime.size =
                new ParticleSystem.MinMaxCurve(
                    1f,
                    sizeCurve);

            ParticleSystemRenderer particleRenderer =
                emitterObject.GetComponent<ParticleSystemRenderer>();

            particleRenderer.renderMode =
                ParticleSystemRenderMode.Billboard;

            particleRenderer.sortingOrder =
                surferWithinWaveSortingOrder + 3;

            // Find a shader supported by the active render pipeline.
            Shader shader =
                Shader.Find(
                    "Universal Render Pipeline/Particles/Unlit");

            if (shader == null)
            {
                shader =
                    Shader.Find(
                        "Universal Render Pipeline/2D/Sprite-Unlit-Default");
            }

            if (shader == null)
                shader = Shader.Find("Sprites/Default");

            if (shader == null)
            {
                Debug.LogWarning(
                    "Could not find a compatible shader for the death blood particles.",
                    this);

                Destroy(emitterObject);
                deathBloodParticles = null;
                return;
            }

            deathBloodMaterial =
                new Material(shader)
                {
                    name = $"{name} Basic Blood Material",
                    hideFlags = HideFlags.HideAndDontSave
                };

            // Ordinary red, with no HDR or emission.
            if (deathBloodMaterial.HasProperty("_BaseColor"))
            {
                deathBloodMaterial.SetColor(
                    "_BaseColor",
                    bloodRed);
            }

            if (deathBloodMaterial.HasProperty("_Color"))
            {
                deathBloodMaterial.SetColor(
                    "_Color",
                    bloodRed);
            }

            // Disable emission so fading alpha actually removes the particles.
            deathBloodMaterial.DisableKeyword("_EMISSION");

            if (deathBloodMaterial.HasProperty("_EmissionColor"))
            {
                deathBloodMaterial.SetColor(
                    "_EmissionColor",
                    Color.black);
            }

            // Force ordinary transparent alpha blending.
            if (deathBloodMaterial.HasProperty("_Surface"))
                deathBloodMaterial.SetFloat("_Surface", 1f);

            if (deathBloodMaterial.HasProperty("_Blend"))
                deathBloodMaterial.SetFloat("_Blend", 0f);

            if (deathBloodMaterial.HasProperty("_SrcBlend"))
            {
                deathBloodMaterial.SetFloat(
                    "_SrcBlend",
                    (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
            }

            if (deathBloodMaterial.HasProperty("_DstBlend"))
            {
                deathBloodMaterial.SetFloat(
                    "_DstBlend",
                    (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            }

            if (deathBloodMaterial.HasProperty("_ZWrite"))
                deathBloodMaterial.SetFloat("_ZWrite", 0f);

            deathBloodMaterial.DisableKeyword(
                "_ALPHAPREMULTIPLY_ON");

            deathBloodMaterial.DisableKeyword(
                "_ALPHAMODULATE_ON");

            deathBloodMaterial.renderQueue =
                (int)UnityEngine.Rendering.RenderQueue.Transparent;

            particleRenderer.sharedMaterial =
                deathBloodMaterial;
        }

        private void UpdateDeathResponse(float dt)
        {
            deathTimer += dt;
            Vector3 position = transform.position;
            deathVelocity.y -= deathSinkSpeed * dt;
            position += (Vector3)(deathVelocity * dt);
            transform.position = position;
            transform.Rotate(0f, 0f, deathSpinSpeed * dt * (deathVelocity.x >= 0f ? -1f : 1f));

            float normalized = Mathf.Clamp01(deathTimer / Mathf.Max(0.01f, deathDuration));
            if (spriteRenderer != null)
            {
                Color faded = livingColor;
                faded.a = 1f - normalized;
                spriteRenderer.color = faded;
            }

            if (deathTimer < deathDuration)
                return;

            if (!respawnAfterDeath)
            {
                gameObject.SetActive(false);
                return;
            }

            respawnTimer += dt;
            if (respawnTimer >= respawnDelay)
                RespawnAfterShark();
        }

        private void RespawnAfterShark()
        {
            if (simulations.Count == 0)
                RefreshWaveList();
            if (simulations.Count == 0)
                return;

            int safeWave = Mathf.Clamp(waveIndex, 0, simulations.Count - 1);
            PickWave(safeWave, true);
            Vector3 p = GetStartingPosition(currentWave);
            p.x = ClampPlayerXToSandbox((currentWave.TankMinimum.x + currentWave.TankMaximum.x) * 0.5f);
            localRideX = p.x;
            transform.position = p;
            transform.rotation = Quaternion.identity;
            transform.localScale = livingScale;
            direction = 1f;
            state = RiderState.Riding;
            UpdateAnimation(false, true);
            deathTimer = 0f;
            respawnTimer = 0f;
            currentHealth = MaximumHealth;
            healthBar?.SetHealth(currentHealth, MaximumHealth);
            if (spriteRenderer != null) spriteRenderer.color = livingColor;
            Collider2D collider = GetComponent<Collider2D>();
            if (collider != null) collider.enabled = true;
        }

        public void ConfigureGeneratedSurfer(
            int wave,
            bool movingRight,
            float speed,
            Color shirt,
            Color board,
            int order,
            float initialLayerJumpDelay,
            float personalIntervalOffset)
        {
            startingWaveIndex = wave;
            startMovingRight = movingRight;
            horizontalRideSpeed = speed;
            shirtColor = shirt;
            boardColor = board;
            sortingOrder = order;
            secondsPerSimulation = Mathf.Max(
                1f,
                secondsPerSimulation + personalIntervalOffset);

            // sortingOrder remains available as legacy configuration, while the
            // active queue/order is derived from the wave being ridden.
            RefreshWaveList();
            direction = movingRight ? 1f : -1f;
            PickWave(wave, true);
            ScheduleNextLayerJump(initialLayerJumpDelay);
        }

        public void ConfigureSinglePlayer(float scrollSpeed, float boostMultiplier)
        {
            playerControlled = true;
            randomizeInitialOceanSpawn = true;
            playerIdleTimer = 0f;
            playerScrollSpeed = Mathf.Max(0.25f, scrollSpeed);
            playerBoostMultiplier = Mathf.Max(1f, boostMultiplier);
            cycleContinuously = false;
            jumpToRandomWaveLayer = false;
            direction = 1f;
            // Sandbox mode moves the surfer through the existing simulation.
            // The wave rows remain fixed and are never wrapped or shifted.
            lockPlayerToScreenX = false;
            RefreshWaveList();
            PickWave(Mathf.Clamp(startingWaveIndex, 0, Mathf.Max(0, simulations.Count - 1)), true);
            localRideX = ClampPlayerXToSandbox(localRideX);
            Vector3 p = transform.position;
            p.x = localRideX;
            transform.position = p;
        }

        private void Update()
        {
            if (state == RiderState.Dead)
            {
                if (speechBubble != null) speechBubble.HideImmediate();
                UpdateDeathResponse(Time.deltaTime);
                return;
            }

            UpdateSpeechBubbles();

            if (simulations.Count == 0)
            {
                RefreshWaveList();
                if (simulations.Count == 0) return;
                PickWave(startingWaveIndex, true);
            }

            simulations.RemoveAll(w => w == null || !w.isActiveAndEnabled);
            if (simulations.Count == 0) return;

            if (currentWave == null || !currentWave.isActiveAndEnabled)
                PickWave(Mathf.Clamp(waveIndex, 0, simulations.Count - 1), true);

            if (playerControlled)
            {
                UpdatePlayerControl(Time.deltaTime);
                return;
            }

            float dt = Time.deltaTime;
            waveTimer += dt;
            stateTimer += dt;

            if (state == RiderState.SwitchingWave)
            {
                UpdateAnimation(true);
                UpdateWaveSwitch();
                return;
            }

            UpdateAnimation(true);

            if (state == RiderState.TurningTrick)
                UpdateTurnTrick();
            else
                UpdateRide(dt);

            if (waveTimer >= currentSimulationDuration &&
                simulations.Count > 1 &&
                cycleContinuously &&
                state == RiderState.Riding)
            {
                BeginNextWave();
            }
        }

        [ContextMenu("Refresh Wave Simulations")]
        public void RefreshWaveList()
        {
            PixelWaterGPU previouslySelectedWave = currentWave;

            int desiredLayer = previouslySelectedWave != null
                ? previouslySelectedWave.IndependentLayerIndex
                : waveIndex;

            simulations.Clear();
            simulations.AddRange(EndlessWaveSections.LayersNearest(localRideX));
            simulations.RemoveAll(w => w == null || !w.isActiveAndEnabled || w.gameObject == gameObject);
            simulations.Sort((a, b) => a.IndependentLayerIndex.CompareTo(b.IndependentLayerIndex));

            if (simulations.Count > 0)
            {
                int selectedIndex = simulations.FindIndex(w => w.IndependentLayerIndex == desiredLayer);
                if (selectedIndex < 0) selectedIndex = Mathf.Clamp(desiredLayer, 0, simulations.Count - 1);
                waveIndex = selectedIndex;
                currentWave = simulations[selectedIndex];
            }
        }

        private void UpdatePlayerControl(float dt)
        {
            ReadPlayerInput(out float horizontal, out bool jumpHeld,
                out bool layerUpHeld, out bool layerDownHeld, out bool boostHeld,
                out float trickInput);
            playerTrickInput = trickInput;

            bool attackHeld = ReadAttackInput();
            if (attackHeld && !previousAttackHeld) PerformAction(layerUpHeld);
            previousAttackHeld = attackHeld;

            float targetSpeed = horizontal * playerScrollSpeed *
                (boostHeld ? playerBoostMultiplier : 1f);
            float response = Mathf.Abs(targetSpeed) > 0.01f
                ? playerAcceleration
                : playerDeceleration;
            playerHorizontalVelocity = Mathf.MoveTowards(
                playerHorizontalVelocity,
                targetSpeed,
                response * dt);

            bool canMove = state == RiderState.Riding || state == RiderState.TurningTrick;
            if (canMove)
            {
                float control = state == RiderState.TurningTrick ? airControl : 1f;
                localRideX += playerHorizontalVelocity * control * dt;
                if (Mathf.Abs(playerHorizontalVelocity) > 0.02f)
                    direction = Mathf.Sign(playerHorizontalVelocity);
            }

            RebindToNearestHorizontalSection();

            bool moving = Mathf.Abs(playerHorizontalVelocity) > 0.03f &&
                state == RiderState.Riding;
            bool hasPlayerActivity = moving || jumpHeld || layerUpHeld || layerDownHeld ||
                Mathf.Abs(trickInput) > 0.05f;

            if (hasPlayerActivity || state != RiderState.Riding)
                playerIdleTimer = 0f;
            else
                playerIdleTimer += dt;

            UpdateAnimation(moving);
            localRideX = ClampPlayerXToSandbox(localRideX);

            // Jump is now the required commit button for player wave changes.
            // Hold a vertical direction, then press Jump:
            //   Up + Space / controller A   -> trick-jump one wave upward
            //   Down + Space / controller A -> trick-jump one wave downward
            // Pressing Jump without a vertical direction performs a normal trick
            // jump and remains on the current wave. Up/Down by themselves do not
            // switch waves anymore.
            bool jumpPressed = jumpHeld && !previousJumpHeld;
            if (jumpPressed && state == RiderState.Riding)
            {
                bool wantsUp = layerUpHeld && !layerDownHeld;
                bool wantsDown = layerDownHeld && !layerUpHeld;

                if (wantsUp || wantsDown)
                {
                    BeginAdjacentWave(wantsUp ? +1 : -1);
                    layerSwitchInputLocked = true;
                }
                else
                {
                    BeginTurnTrick();
                }
            }

            // Release Jump before another normal jump or wave-switch jump can
            // begin. The direction may remain held, which makes the combination
            // responsive without allowing repeated automatic layer changes.
            if (!jumpHeld)
                layerSwitchInputLocked = false;

            previousJumpHeld = jumpHeld;
            previousLayerUpHeld = layerUpHeld;
            previousLayerDownHeld = layerDownHeld;

            stateTimer += dt;
            if (state == RiderState.SwitchingWave)
                UpdateWaveSwitch();
            else if (state == RiderState.TurningTrick)
                UpdateTurnTrick();
            else
            {
                localRideX = ClampPlayerXToSandbox(localRideX);
                FollowSurface(dt);
            }
        }

        private void BeginAdjacentWave(int step)
        {
            if (state != RiderState.Riding)
                return;

            if (speechBubble != null) speechBubble.HideImmediate();

            // Refresh first because the independent layers are generated at
            // runtime. This also restores a strict 0..N layer-index order.
            RefreshWaveList();

            if (simulations.Count <= 1)
                return;

            step = Mathf.Clamp(step, -1, 1);
            if (step == 0)
                return;

            // Never trust an old numeric index. Resolve the surfer's current
            // wave by reference, then move exactly one entry in the sorted list.
            int currentIndex = simulations.IndexOf(currentWave);
            if (currentIndex < 0)
                currentIndex = Mathf.Clamp(waveIndex, 0, simulations.Count - 1);

            int nextIndex = currentIndex + step;

            // Wrap only when pressing outward at either end of the full stack.
            if (nextIndex < 0)
                nextIndex = simulations.Count - 1;
            else if (nextIndex >= simulations.Count)
                nextIndex = 0;

            PixelWaterGPU nextWave = simulations[nextIndex];
            if (nextWave == null || nextWave == currentWave)
                return;

            layerSwitchInputLocked = true;
            currentWave = nextWave;
            waveIndex = nextIndex;

            ApplyCurrentWaveSorting(true);

            stateTimer = 0f;
            state = RiderState.SwitchingWave;
            renderDepth = currentWave.transform.position.z - 0.02f;

            switchStart = transform.position;
            switchTarget = GetStartingPosition(currentWave);
            switchTarget.x = ClampPlayerXToSandbox(localRideX);
            switchTarget.z = renderDepth;
        }

        private void RebindToNearestHorizontalSection()
        {
            EndlessWaveSections endless = EndlessWaveSections.Instance;
            if (endless == null || !endless.IsReady || currentWave == null)
                return;

            // Keep the same vertical layer while crossing a horizontal seam.
            float padding = 0.02f;
            if (localRideX >= currentWave.TankMinimum.x - padding &&
                localRideX <= currentWave.TankMaximum.x + padding)
                return;

            int verticalLayer = currentWave.IndependentLayerIndex;
            List<PixelWaterGPU> nearest = EndlessWaveSections.LayersNearest(localRideX);
            PixelWaterGPU replacement = nearest.Find(w => w.IndependentLayerIndex == verticalLayer);
            if (replacement == null || replacement == currentWave)
                return;

            simulations.Clear();
            simulations.AddRange(nearest);
            simulations.Sort((a, b) => a.IndependentLayerIndex.CompareTo(b.IndependentLayerIndex));
            currentWave = replacement;
            waveIndex = simulations.IndexOf(replacement);
            renderDepth = currentWave.transform.position.z - 0.02f;
            ApplyCurrentWaveSorting(true);
        }

        private float ClampPlayerXToSandbox(float desiredX)
        {
            EndlessWaveSections endless = EndlessWaveSections.Instance;
            if (endless != null && endless.IsReady)
            {
                // Only clamp against the far outside edges of the active three
                // sections. Normal section seams remain completely traversable.
                float minimumX = endless.MinimumWorldX + playerCameraEdgePadding;
                float maximumX = endless.MaximumWorldX - playerCameraEdgePadding;
                return minimumX <= maximumX
                    ? Mathf.Clamp(desiredX, minimumX, maximumX)
                    : desiredX;
            }

            if (currentWave == null)
                return desiredX;

            Vector2 waveMin = currentWave.TankMinimum;
            Vector2 waveMax = currentWave.TankMaximum;
            float waveWidth = Mathf.Max(0.01f, waveMax.x - waveMin.x);
            float wavePadding = waveWidth * edgePadding;
            return Mathf.Clamp(desiredX, waveMin.x + wavePadding, waveMax.x - wavePadding);
        }

        private void ReadPlayerInput(out float horizontal, out bool jump,
            out bool layerUp, out bool layerDown, out bool boost, out float trick)
        {
#if ENABLE_INPUT_SYSTEM
            horizontal = 0f;
            jump = layerUp = layerDown = boost = false;
            trick = 0f;

            Keyboard keyboard = Keyboard.current;
            if (keyboard != null)
            {
                horizontal += (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed ? 1f : 0f)
                    - (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed ? 1f : 0f);
                jump |= keyboard.spaceKey.isPressed;
                layerUp |= keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed;
                layerDown |= keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed;
                boost |= keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed;
                trick += (keyboard.eKey.isPressed ? 1f : 0f) - (keyboard.qKey.isPressed ? 1f : 0f);
            }

            Gamepad gamepad = Gamepad.current;
            if (gamepad != null)
            {
                float stickX = gamepad.leftStick.x.ReadValue();
                if (Mathf.Abs(stickX) >= gamepadDeadZone)
                    horizontal = stickX;

                if (gamepad.dpad.left.isPressed)
                    horizontal = -1f;
                else if (gamepad.dpad.right.isPressed)
                    horizontal = 1f;

                jump |= gamepad.buttonSouth.isPressed;          // Xbox A

                // D-pad Up/Down and the left stick vertical axis are wave-jump
                // modifiers. They only cause a layer change when controller A
                // is newly pressed, so vertical stick input never switches waves
                // by itself.
                float stickY = gamepad.leftStick.y.ReadValue();
                layerUp |= gamepad.dpad.up.isPressed || stickY >= gamepadDeadZone;
                layerDown |= gamepad.dpad.down.isPressed || stickY <= -gamepadDeadZone;

                boost |= gamepad.rightTrigger.ReadValue() > 0.2f;

                float rightX = gamepad.rightStick.x.ReadValue();
                if (Mathf.Abs(rightX) >= gamepadDeadZone)
                    trick = rightX;
            }

            horizontal = Mathf.Clamp(horizontal, -1f, 1f);
            trick = Mathf.Clamp(trick, -1f, 1f);
            return;
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            horizontal = Input.GetAxisRaw("Horizontal");
            jump = Input.GetKey(KeyCode.Space) || Input.GetButton("Jump");
            layerUp = Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
            layerDown = Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow);
            boost = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
            trick = (Input.GetKey(KeyCode.E) ? 1f : 0f) - (Input.GetKey(KeyCode.Q) ? 1f : 0f);
#else
            horizontal = trick = 0f;
            jump = layerUp = layerDown = boost = false;
#endif
        }

        private void UpdateRide(float dt)
        {
            Vector2 min = currentWave.TankMinimum;
            Vector2 max = currentWave.TankMaximum;
            float width = Mathf.Max(0.01f, max.x - min.x);
            float left = min.x + width * edgePadding;
            float right = max.x - width * edgePadding;

            Vector2 waveVelocity = currentWave.GetGameplayWaveVelocity(localRideX);
            float waveAssist = waveVelocity.x * waveVelocityInfluence * direction;
            localRideX += direction *
                Mathf.Max(0.2f, horizontalRideSpeed + waveAssist) * dt;

            if (localRideX >= right)
            {
                localRideX = right;
                BeginTurnTrick();
                return;
            }

            if (localRideX <= left)
            {
                localRideX = left;
                BeginTurnTrick();
                return;
            }

            FollowSurface(dt);
        }

        private void FollowSurface(float dt)
        {
            float surfaceY = currentWave.GetGameplaySurfaceHeight(localRideX);

            const float sample = 0.09f;
            float leftY = currentWave.GetGameplaySurfaceHeight(localRideX - sample);
            float rightY = currentWave.GetGameplaySurfaceHeight(localRideX + sample);

            float slope = Mathf.Atan2(
                rightY - leftY,
                sample * 2f) * Mathf.Rad2Deg;

            float speedRatio = playerControlled
                ? Mathf.Clamp01(
                    Mathf.Abs(direction) * playerScrollSpeed /
                    Mathf.Max(
                        0.01f,
                        playerScrollSpeed * playerBoostMultiplier))
                : Mathf.Clamp01(horizontalRideSpeed / 2f);

            float waterMotion = Mathf.Clamp01(
                Mathf.Abs(
                    currentWave.GetGameplayWaveVelocity(localRideX).y));

            float bobPhase =
                Time.time *
                idleBobFrequency *
                Mathf.PI *
                2f +
                waveIndex * 0.73f;

            float bob =
                Mathf.Sin(bobPhase) *
                idleBobHeight *
                (0.35f + waterMotion * 0.65f);

            Vector3 target = new Vector3(
                localRideX,
                surfaceY + surfaceOffset + bob,
                renderDepth);

            if (playerControlled && state == RiderState.Riding)
            {
                transform.position = target;
            }
            else
            {
                transform.position = Vector3.Lerp(
                    transform.position,
                    target,
                    1f - Mathf.Exp(-surfaceFollow * dt));
            }

            float compression =
                Mathf.Sin(bobPhase + Mathf.PI * 0.5f) *
                stanceSquash *
                (0.4f + speedRatio * 0.6f);

            float xScale =
                spriteWorldScale *
                (1f + compression * 0.35f);

            float yScale =
                spriteWorldScale *
                (1f - compression);

            ApplyFacing(xScale, yScale);

            float balanceLean =
                -direction *
                directionalLean *
                speedRatio;

            float microPitch =
                Mathf.Cos(bobPhase) *
                1.2f *
                waterMotion;

            transform.rotation = Quaternion.Lerp(
                transform.rotation,
                Quaternion.Euler(
                    0f,
                    0f,
                    slope + balanceLean + microPitch),
                1f - Mathf.Exp(-surfaceFollow * 0.7f * dt));
        }
        private void BeginTurnTrick()
        {
            if (speechBubble != null) speechBubble.HideImmediate();
            state = RiderState.TurningTrick;
            stateTimer = 0f;
            airStartY = currentWave.GetGameplaySurfaceHeight(localRideX) + surfaceOffset;
            flipTrick = Random.value < flipChance;
        }

        private void UpdateTurnTrick()
        {
            float t = Mathf.Clamp01(
                stateTimer /
                Mathf.Max(0.01f, turnTrickDuration));

            float surfaceY =
                currentWave.GetGameplaySurfaceHeight(localRideX);

            float baseArc = Mathf.Sin(t * Mathf.PI);
            float arc = Mathf.Pow(Mathf.Max(0f, baseArc), playerJumpArcPower) *
                turnJumpHeight;

            transform.position = new Vector3(
                localRideX,
                Mathf.Max(
                    surfaceY + surfaceOffset,
                    airStartY + arc),
                renderDepth);

            float spinDirection =
                direction >= 0f ? -1f : 1f;

            float automaticSpin = turnSpinDegrees * spinDirection * t;
            float controlledSpin = playerControlled
                ? playerTrickInput * playerAirTrickDegrees * t
                : 0f;
            transform.rotation = Quaternion.Euler(
                0f,
                0f,
                automaticSpin + controlledSpin);

            float flipAmount = flipTrick
                ? Mathf.Cos(t * Mathf.PI * 2f)
                : 1f;

            float trickScale =
                spriteWorldScale *
                Mathf.Max(
                    0.18f,
                    Mathf.Abs(flipAmount));

            ApplyFacing(
                trickScale,
                spriteWorldScale);

            // Temporarily reverse the visual during the middle of a flip trick.
            if (flipTrick &&
                spriteRenderer != null &&
                flipAmount < 0f)
            {
                spriteRenderer.flipX =
                    !spriteRenderer.flipX;
            }

            if (t < 1f)
                return;

            if (!playerControlled)
                direction *= -1f;

            state = RiderState.Riding;
            stateTimer = 0f;

            transform.rotation = Quaternion.identity;

            ApplyFacing(
                spriteWorldScale,
                spriteWorldScale);
        }

        [ContextMenu("Ride Next Wave")]
        public void BeginNextWave()
        {
            if (speechBubble != null) speechBubble.HideImmediate();
            if (simulations.Count <= 1)
            {
                waveTimer = 0f;
                return;
            }

            int next;
            if (jumpToRandomWaveLayer && simulations.Count > 2)
            {
                next = waveIndex;
                int safety = 0;
                while (next == waveIndex && safety++ < 12)
                    next = Random.Range(0, simulations.Count);
            }
            else
            {
                next = (waveIndex + 1) % simulations.Count;
            }

            currentWave = simulations[next];
            waveIndex = next;
            ApplyCurrentWaveSorting(true);
            waveTimer = 0f;
            ScheduleNextLayerJump(0f);
            stateTimer = 0f;
            state = RiderState.SwitchingWave;
            renderDepth = currentWave.transform.position.z - 0.02f;

            switchStart = transform.position;
            switchTarget = GetStartingPosition(currentWave);
            switchTarget.z = renderDepth;
        }

        private void UpdateWaveSwitch()
        {
            float t = Mathf.Clamp01(
                stateTimer /
                Mathf.Max(0.01f, switchDuration));

            float eased =
                t * t * (3f - 2f * t);

            Vector3 p = Vector3.Lerp(
                switchStart,
                switchTarget,
                eased);

            float layerDistance =
                Mathf.Abs(
                    switchTarget.y -
                    switchStart.y);

            float jump =
                layerJumpHeight +
                layerDistance * 0.35f;

            p.y +=
                Mathf.Sin(t * Mathf.PI) *
                jump;

            transform.position = p;

            float spinDirection =
                direction >= 0f ? -1f : 1f;

            transform.rotation = Quaternion.Euler(
                0f,
                0f,
                540f * spinDirection * eased);

            float tuck =
                1f -
                Mathf.Sin(t * Mathf.PI) *
                0.35f;

            ApplyFacing(
                spriteWorldScale * tuck,
                spriteWorldScale * tuck);

            if (t < 1f)
                return;

            localRideX =
                playerControlled && lockPlayerToScreenX
                    ? playerScreenX
                    : switchTarget.x;

            if (playerControlled && lockPlayerToScreenX)
                switchTarget.x = playerScreenX;

            transform.position = switchTarget;
            transform.rotation = Quaternion.identity;

            state = RiderState.Riding;
            stateTimer = 0f;

            ApplyFacing(
                spriteWorldScale,
                spriteWorldScale);
        }

        private void ScheduleNextLayerJump(float initialDelay)
        {
            float variation = Random.Range(
                -simulationTimeVariation,
                simulationTimeVariation);

            currentSimulationDuration = Mathf.Max(
                1f,
                secondsPerSimulation + variation);

            // A negative timer creates a unique initial delay without forcing
            // every surfer to jump at scene start.
            waveTimer = -Mathf.Max(0f, initialDelay);
        }

        [ContextMenu("Spawn Randomly In Ocean")]
        public void SpawnAtRandomOceanPosition()
        {
            EndlessWaveSections endless = EndlessWaveSections.Instance;

            float minimumX;
            float maximumX;

            if (endless != null && endless.IsReady)
            {
                minimumX = endless.MinimumWorldX;
                maximumX = endless.MaximumWorldX;
            }
            else
            {
                PixelWaterGPU fallback = Object.FindFirstObjectByType<PixelWaterGPU>();
                if (fallback == null)
                    return;

                minimumX = fallback.TankMinimum.x;
                maximumX = fallback.TankMaximum.x;
            }

            float oceanWidth = Mathf.Max(0.01f, maximumX - minimumX);
            float padding = oceanWidth * Mathf.Clamp(randomSpawnEdgePadding, 0f, 0.45f);
            float left = minimumX + padding;
            float right = maximumX - padding;

            if (left > right)
            {
                float centre = (minimumX + maximumX) * 0.5f;
                left = centre;
                right = centre;
            }

            List<Transform> enemies = CollectSpawnEnemies();
            int attempts = Mathf.Max(1, safeSpawnAttempts);

            PixelWaterGPU bestWave = null;
            Vector3 bestPosition = transform.position;
            float bestX = left;
            float bestClearance = float.NegativeInfinity;

            for (int attempt = 0; attempt < attempts; attempt++)
            {
                float candidateX = Random.Range(left, right);
                List<PixelWaterGPU> candidateLayers = EndlessWaveSections.LayersNearest(candidateX);
                candidateLayers.RemoveAll(w => w == null || !w.isActiveAndEnabled);
                candidateLayers.Sort((a, b) =>
                    a.IndependentLayerIndex.CompareTo(b.IndependentLayerIndex));

                if (candidateLayers.Count == 0)
                    continue;

                PixelWaterGPU candidateWave = candidateLayers[Random.Range(0, candidateLayers.Count)];
                candidateX = Mathf.Clamp(
                    candidateX,
                    candidateWave.TankMinimum.x + 0.02f,
                    candidateWave.TankMaximum.x - 0.02f);

                Vector3 candidatePosition = GetStartingPosition(candidateWave);
                candidatePosition.x = candidateX;
                candidatePosition.y = candidateWave.GetGameplaySurfaceHeight(candidateX) + surfaceOffset;
                candidatePosition.z = candidateWave.transform.position.z - 0.02f;

                float clearance = GetNearestEnemyDistance(candidatePosition, enemies);
                if (clearance > bestClearance)
                {
                    bestClearance = clearance;
                    bestWave = candidateWave;
                    bestPosition = candidatePosition;
                    bestX = candidateX;
                }

                if (clearance >= enemySafeSpawnRadius)
                    break;
            }

            if (bestWave == null)
                return;

            List<PixelWaterGPU> nearbyLayers = EndlessWaveSections.LayersNearest(bestX);
            nearbyLayers.RemoveAll(w => w == null || !w.isActiveAndEnabled);
            nearbyLayers.Sort((a, b) =>
                a.IndependentLayerIndex.CompareTo(b.IndependentLayerIndex));

            simulations.Clear();
            simulations.AddRange(nearbyLayers);

            waveIndex = simulations.IndexOf(bestWave);
            if (waveIndex < 0)
            {
                simulations.Add(bestWave);
                simulations.Sort((a, b) =>
                    a.IndependentLayerIndex.CompareTo(b.IndependentLayerIndex));
                waveIndex = simulations.IndexOf(bestWave);
            }

            currentWave = bestWave;
            direction = Random.value < 0.5f ? -1f : 1f;
            startMovingRight = direction > 0f;
            localRideX = bestX;
            renderDepth = bestPosition.z;
            state = RiderState.Riding;
            stateTimer = 0f;
            waveTimer = 0f;

            transform.position = bestPosition;
            transform.rotation = Quaternion.identity;
            ApplyCurrentWaveSorting(true);
            UpdateAnimation(false, true);
        }

        private static List<Transform> CollectSpawnEnemies()
        {
            List<Transform> enemies = new();

            foreach (SharkLaneSwimmer shark in
                     Object.FindObjectsByType<SharkLaneSwimmer>(FindObjectsSortMode.None))
            {
                if (shark != null && shark.isActiveAndEnabled)
                    enemies.Add(shark.transform);
            }

            foreach (GiantSquidLaneSwimmer squid in
                     Object.FindObjectsByType<GiantSquidLaneSwimmer>(FindObjectsSortMode.None))
            {
                if (squid != null && squid.isActiveAndEnabled)
                    enemies.Add(squid.transform);
            }

            return enemies;
        }

        private static float GetNearestEnemyDistance(
            Vector3 candidatePosition,
            List<Transform> enemies)
        {
            if (enemies == null || enemies.Count == 0)
                return float.PositiveInfinity;

            float nearestSquared = float.PositiveInfinity;
            Vector2 candidate = candidatePosition;

            foreach (Transform enemy in enemies)
            {
                if (enemy == null)
                    continue;

                float squaredDistance =
                    ((Vector2)enemy.position - candidate).sqrMagnitude;

                if (squaredDistance < nearestSquared)
                    nearestSquared = squaredDistance;
            }

            return Mathf.Sqrt(nearestSquared);
        }

        private void PickWave(int index, bool snap)
        {
            if (simulations.Count == 0) return;

            waveIndex = Mathf.Abs(index) % simulations.Count;
            currentWave = simulations[waveIndex];
            ApplyCurrentWaveSorting(true);
            stateTimer = 0f;
            state = RiderState.Riding;
            renderDepth = currentWave.transform.position.z - 0.02f;

            Vector2 min = currentWave.TankMinimum;
            Vector2 max = currentWave.TankMaximum;
            float width = max.x - min.x;
            localRideX = direction > 0f
                ? min.x + width * (edgePadding + 0.08f)
                : max.x - width * (edgePadding + 0.08f);

            Vector3 start = GetStartingPosition(currentWave);
            start.x = localRideX;
            start.z = renderDepth;
            if (snap) transform.position = start;
        }

        private Vector3 GetStartingPosition(PixelWaterGPU wave)
        {
            Vector2 min = wave.TankMinimum;
            Vector2 max = wave.TankMaximum;
            float x = Mathf.Lerp(min.x, max.x, 0.5f);
            float y = wave.GetGameplaySurfaceHeight(x) + surfaceOffset;
            return new Vector3(x, y, wave.transform.position.z - 0.02f);
        }

        private void EnsurePixelSprite()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();

            if (spriteRenderer == null)
                spriteRenderer = gameObject.AddComponent<SpriteRenderer>();

            Sprite imported = Resources.Load<Sprite>(surferSpriteResource);

            if (imported == null)
            {
                Sprite[] importedSprites = Resources.LoadAll<Sprite>(surferSpriteResource);
                if (importedSprites != null && importedSprites.Length > 0)
                    imported = importedSprites[0];
            }

            if (imported != null)
            {
                spriteRenderer.sprite = imported;
                spriteRenderer.sortingOrder = surferWithinWaveSortingOrder;
                spriteRenderer.color = Color.white;

                ApplyFacing(
                    spriteWorldScale,
                    spriteWorldScale);

                return;
            }

            Debug.LogWarning(
                $"TinyWaveSurfer could not load Resources/{surferSpriteResource}. " +
                "Falling back to a generated marker.",
                this);

            runtimeTexture = new Texture2D(
                8,
                8,
                TextureFormat.RGBA32,
                false)
            {
                name = "Fallback Tiny Surfer",
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Clamp
            };

            Color[] pixels = new Color[64];

            void Set(int x, int y, Color color)
            {
                if (x < 0 ||
                    x >= 8 ||
                    y < 0 ||
                    y >= 8)
                {
                    return;
                }

                pixels[y * 8 + x] = color;
            }

            for (int x = 1; x <= 6; x++)
                Set(x, 1, boardColor);

            Set(3, 2, bodyColor);
            Set(5, 2, bodyColor);

            Set(3, 3, bodyColor);
            Set(4, 3, bodyColor);

            Set(4, 4, shirtColor);
            Set(4, 5, shirtColor);
            Set(3, 5, shirtColor);
            Set(5, 5, shirtColor);

            Set(2, 5, bodyColor);
            Set(6, 5, bodyColor);

            Set(4, 6, bodyColor);
            Set(4, 7, bodyColor);
            Set(3, 7, bodyColor);

            runtimeTexture.SetPixels(pixels);
            runtimeTexture.Apply(false, false);

            runtimeSprite = Sprite.Create(
                runtimeTexture,
                new Rect(
                    0f,
                    0f,
                    8f,
                    8f),
                new Vector2(
                    0.5f,
                    0.18f),
                8f,
                0,
                SpriteMeshType.FullRect);

            spriteRenderer.sprite =
                runtimeSprite;

            spriteRenderer.sortingOrder =
                surferWithinWaveSortingOrder;

            spriteRenderer.color =
                Color.white;

            ApplyFacing(
                spriteWorldScale,
                spriteWorldScale);
        }
    }

    public static class TinyWaveSurferBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void CreateTinySurfers()
        {
            if (Object.FindFirstObjectByType<PixelWaterGPU>() == null)
                return;

            if (Object.FindObjectsByType<TinyWaveSurfer>(
                    FindObjectsInactive.Exclude,
                    FindObjectsSortMode.None).Length > 0)
                return;

            Color[] shirts =
            {
                new(0.95f, 0.30f, 0.12f, 1f),
                new(0.12f, 0.68f, 0.95f, 1f),
                new(0.66f, 0.20f, 0.90f, 1f),
                new(0.15f, 0.85f, 0.42f, 1f),
                new(0.95f, 0.75f, 0.12f, 1f),
                new(0.95f, 0.25f, 0.62f, 1f)
            };

            Color[] boards =
            {
                new(1f, 0.88f, 0.24f, 1f),
                new(0.95f, 0.95f, 1f, 1f),
                new(0.20f, 0.95f, 0.85f, 1f),
                new(1f, 0.42f, 0.18f, 1f),
                new(0.45f, 0.85f, 1f, 1f),
                new(0.85f, 0.95f, 0.28f, 1f)
            };

            PixelWaterGPU master = Object.FindFirstObjectByType<PixelWaterGPU>();
            bool singlePlayer = master != null && master.SinglePlayerModeEnabled;
            int surferCount = singlePlayer ? 1 : 6;
            for (int i = 0; i < surferCount; i++)
            {
                GameObject go = new($"Tiny 8x8 Surfer {i + 1}");
                TinyWaveSurfer surfer = go.AddComponent<TinyWaveSurfer>();
                surfer.ConfigureGeneratedSurfer(
                    i,
                    (i & 1) == 0,
                    0.95f + i * 0.11f,
                    shirts[i],
                    boards[i],
                    100 + i,
                    1.25f + i * 1.85f,
                    (i - 2.5f) * 0.55f);

                if (singlePlayer)
                    surfer.ConfigureSinglePlayer(
                        master.SinglePlayerScrollSpeed,
                        master.SinglePlayerBoostMultiplier);
            }
        }
    }
}
