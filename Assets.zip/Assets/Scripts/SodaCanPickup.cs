using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace PixelOcean
{
    [RequireComponent(typeof(SpriteRenderer), typeof(Rigidbody2D), typeof(InterWaveRenderItem))]
    public sealed class SodaCanPickup : MonoBehaviour
    {
        private readonly List<PixelWaterGPU> layers = new();
        private Rigidbody2D body; private SpriteRenderer sr; private SodaCanSpawner owner;
        private int lane; private float dir, speed, phase; private bool ready, collected;
        public void Initialise(int laneIndex, SodaCanSpawner spawner)
        {
            owner = spawner; lane = laneIndex; Resolve();
            GetComponent<InterWaveRenderItem>().SetLane(lane);
            dir = Random.value < .5f ? -1f : 1f; speed = Random.Range(.16f,.34f); phase = Random.value * 6.28f;
            Vector2 p = body.position; p.x = Random.Range(MinX(), MaxX()); p.y = Centre(p.x); body.position = p; ready = true;
        }
        private void Awake() => Resolve();
        private void Resolve(){ body=GetComponent<Rigidbody2D>(); sr=GetComponent<SpriteRenderer>(); layers.Clear(); layers.AddRange(FindObjectsByType<PixelWaterGPU>(FindObjectsSortMode.None).Where(x=>x!=null).OrderBy(x=>x.IndependentLayerIndex)); }
        private void FixedUpdate()
        {
            if(!ready||collected||layers.Count<2)return;
            Vector2 p=body.position; p.x += dir*speed*Time.fixedDeltaTime;
            if(p.x<=MinX()){p.x=MinX();dir=1;} else if(p.x>=MaxX()){p.x=MaxX();dir=-1;}
            p.y=Mathf.Lerp(p.y,Centre(p.x)+Mathf.Sin(Time.time*2.2f+phase)*.045f,1f-Mathf.Exp(-5f*Time.fixedDeltaTime));
            body.MovePosition(p); transform.rotation=Quaternion.Euler(0,0,Mathf.Sin(Time.time*2f+phase)*8f);
            foreach(var s in FindObjectsByType<TinyWaveSurfer>(FindObjectsSortMode.None))
                if(s!=null&&!s.IsDead&&!s.IsSwitchingWave&&(s.CurrentWaveIndex==lane||s.CurrentWaveIndex==lane+1)&&Vector2.Distance(p,s.transform.position)<.5f&&s.CollectSodaCan()) { StartCoroutine(CollectFx(s.transform)); break; }
        }
        private System.Collections.IEnumerator CollectFx(Transform target)
        {
            collected=true; GetComponent<Collider2D>().enabled=false; owner?.NotifyCollected(gameObject);
            Vector3 start=transform.position, scale=transform.localScale;
            for(float e=0;e<.28f;e+=Time.deltaTime){float t=e/.28f;transform.position=Vector3.Lerp(start,target.position+Vector3.up*.22f,t);transform.localScale=scale*(1f+t);sr.color=new Color(1,1,1,1-t);yield return null;}
            Destroy(gameObject);
        }
        private float Centre(float x)=>Mathf.Lerp(layers[lane].GetGameplaySurfaceHeight(x),layers[lane+1].GetGameplaySurfaceHeight(x),.5f);
        private float MinX()=>Mathf.Lerp(Mathf.Max(layers[lane].TankMinimum.x,layers[lane+1].TankMinimum.x),Mathf.Min(layers[lane].TankMaximum.x,layers[lane+1].TankMaximum.x),.07f);
        private float MaxX()=>Mathf.Lerp(Mathf.Min(layers[lane].TankMaximum.x,layers[lane+1].TankMaximum.x),Mathf.Max(layers[lane].TankMinimum.x,layers[lane+1].TankMinimum.x),.07f);
    }
}
