using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PixelOcean
{
    /// <summary>
    /// Turns the existing sandbox systems into one escalating surf-day run.
    /// Installed automatically, so no scene setup is required.
    /// </summary>
    [DefaultExecutionOrder(-12000)]
    [DisallowMultipleComponent]
    public sealed class SurfDayProgressionDirector : MonoBehaviour
    {
        public enum Chapter
        {
            Dawn,
            FirstRescue,
            DangerousWater,
            StrangeTide,
            Storm,
            FinalWave,
            Complete
        }

        [Header("Run Length")]
        [SerializeField, Min(10f)] private float rescueBeginsAt = 20f;
        [SerializeField, Min(20f)] private float dangerBeginsAt = 60f;
        [SerializeField, Min(30f)] private float strangeTideBeginsAt = 130f;
        [SerializeField, Min(40f)] private float stormBeginsAt = 215f;
        [SerializeField, Min(5f)] private float finalWaveBeginsAt = 240f;
        [SerializeField, Min(60f)] private float dayEndsAt = 360f; // six-minute atmospheric fallback

        [Header("Journey Distance")]
        [SerializeField, Min(10f)] private float rescueDistance = 60f;
        [SerializeField, Min(20f)] private float dangerDistance = 160f;
        [SerializeField, Min(30f)] private float strangeTideDistance = 300f;
        [SerializeField, Min(40f)] private float stormDistance = 425f;
        [SerializeField, Min(50f)] private float finalWaveDistance = 525f;
        [SerializeField, Min(60f)] private float dayEndDistance = 650f;
        [SerializeField, Min(60f)] private float dayTwoEndDistance = 725f;
        [SerializeField, Min(60f)] private float dayThreeEndDistance = 800f;
        [SerializeField, Min(60f)] private float dayFourEndDistance = 1100f;
        [SerializeField, Min(60f)] private float dayFiveEndDistance = 900f;
        [SerializeField, Min(60f)] private float sandboxDayEndDistance = 900f;
        [SerializeField, Min(0.001f)] private float distanceDeadZone = 0.015f;
        [SerializeField, Min(0.25f)] private float teleportRejectDistance = 8f;

        [Header("Progressive Ambient Hostiles")]
        [SerializeField, Min(4f)] private float busiestThreatInterval = 9f;
        [SerializeField, Min(6f)] private float quietestThreatInterval = 19f;
        [SerializeField, Min(1)] private int maximumAmbientHostiles = 7;

        [Header("Day 1 Mechanic Introduction")]
        [SerializeField, Min(0f)] private float handstandUnlockAt = 75f;
        [SerializeField, Min(0f)] private float throwingUnlockAt = 90f;
        [SerializeField, Min(0f)] private float waterSkidUnlockAt = 187.5f;
        [SerializeField, Min(0f)] private float waterSlashUnlockAt = 215f;

        [Header("Objectives")]
        [SerializeField, Min(1)] private int rescuesRequired = 3;
        [SerializeField, Min(1)] private int finalSurvivalSeconds = 120;

        [Header("Boss Defeat Sunset")]
        [SerializeField, Min(10f)] private float acceleratedSunsetSeconds = 37.5f;
        [SerializeField, Min(1f)] private float retreatSpeedMultiplier = 0.75f;

        private bool bossDefeatedSunset;

        //[SerializeField] private bool startOnDayTwoForTesting = true; // true

        private readonly List<GameObject> progressionSpawners = new();
        private Chapter chapter;
        private float runTime;
        private float distanceTravelled;
        private float previousPlayerX;
        private bool hasPreviousPlayerX;
        private int rescues;
        private float bannerUntil;
        private string banner = string.Empty;
        private string objective = string.Empty;
        private string learningObjective = string.Empty;
        private bool finalWaveStarted;
        private bool changingDay;
        private bool developerDaySwitchInProgress;
        private bool facilityEncounterStarted;
        private int currentDay = 1;
        private ProceduralRainSystem rain;
        private float nextAtmosphereRefreshTime;
        private float nextDayFourEncounterCheck;
        private float nextFinalEncounterRecoveryCheck;
        private float nextFacilitySpawnAttemptAt;
        private float nextAmbientThreatAt;
        private int ambientThreatDay = -1;
        private ProceduralRainSystem.RainSituation appliedProgressionWeather =
            ProceduralRainSystem.RainSituation.Clear;
        private GUIStyle titleStyle;
        private GUIStyle objectiveStyle;
        private GUIStyle panelStyle;

        public Chapter CurrentChapter => chapter;
        public int Rescues => rescues;
        public float RunTime => runTime;
        public float DistanceTravelled => distanceTravelled;
        public float DayDistance => GetDayEndDistance(currentDay);
        public float NormalizedJourneyProgress => DayDistance > 0f
            ? Mathf.Clamp01(distanceTravelled / DayDistance)
            : 0f;
        public float DistanceToNextChapter => Mathf.Max(0f, GetDistanceThresholdForChapter(GetNextChapter(chapter)) - distanceTravelled);
        public int CurrentDay => currentDay;
        public float DayDuration => dayEndsAt;
        public float NormalizedDayProgress => Mathf.Max(
            dayEndsAt > 0f ? Mathf.Clamp01(runTime / dayEndsAt) : 0f,
            NormalizedJourneyProgress);
        public string CurrentObjective => string.IsNullOrWhiteSpace(learningObjective)
            ? objective
            : objective + "\nLEARN  •  " + learningObjective;
        public string CurrentLearningObjective => learningObjective;
        public string CurrentBanner => banner;
        public bool IsBannerVisible => Time.unscaledTime < bannerUntil && !string.IsNullOrEmpty(banner);

        public SurfStageSaveSystem.SaveData CaptureSaveData()
        {
            SurfStageSaveSystem.SaveData data = new()
            {
                day = currentDay,
                chapter = (int)chapter,
                runTime = runTime,
                distanceTravelled = distanceTravelled,
                rescues = rescues,
                finalWaveStarted = finalWaveStarted,
                bossDefeatedSunset = bossDefeatedSunset
            };

            if (currentDay == 4)
            {
                DayFourConspiracyEncounter encounter =
                    FindFirstObjectByType<DayFourConspiracyEncounter>();
                if (encounter != null)
                {
                    data.dayFourIslandRevealed = encounter.IslandRevealed;
                    data.dayFourIslandDistance = encounter.IslandDistance;
                }
            }

            return data;
        }

        private Coroutine pendingCheckpoint;
        private Coroutine pendingBossEncounter;

        /// <summary>
        /// Saves after the current gameplay state has settled. This is important for
        /// developer jumps and chapter transitions because spawns/destructions are deferred.
        /// </summary>
        private void QueueCheckpoint()
        {
            if (!isActiveAndEnabled)
                return;

            if (pendingCheckpoint != null)
                StopCoroutine(pendingCheckpoint);
            pendingCheckpoint = StartCoroutine(SaveCheckpointAfterFrame());
        }

        private IEnumerator SaveCheckpointAfterFrame()
        {
            yield return null;
            yield return new WaitForEndOfFrame();
            SurfStageSaveSystem.Save(this);
            pendingCheckpoint = null;
        }

        /// <summary>
        /// Keeps the procedural sky tied to the run clock. Each surf day starts
        /// at 6:00 AM and reaches midnight at the end of the configured day.
        /// Continue loads and developer jumps still target the exact story time,
        /// while ProceduralStarryNight eases any large correction without a snap.
        /// </summary>
        private void SyncDayNightToRunTime()
        {
            ProceduralStarryNight sky = FindFirstObjectByType<ProceduralStarryNight>();
            if (sky == null)
                return;

            // Runtime scenes can retain the old serialized twelve-minute sky
            // value even after the script default changes. Keep the fallback
            // cycle duration synchronized with the shortened story day too.
            sky.SetCycleLengthSeconds(dayEndsAt);

            float progress = NormalizedDayProgress;

            // 0.25 = 6:00 AM. Advancing 0.75 of a full cycle reaches midnight.
            float visualTime = Mathf.Repeat(0.25f + progress * 0.75f, 1f);
            sky.SetTimeOfDay(visualTime);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Install()
        {
            if (FindFirstObjectByType<SurfDayProgressionDirector>() != null)
                return;

            GameObject host = new("Surf Day Progression Director");
            DontDestroyOnLoad(host);
            host.AddComponent<SurfDayProgressionDirector>();
        }

        private void OnEnable()
        {
            StrugglingSwimmerDrifter.SwimmerSaved += OnSwimmerSaved;
            AirTrickScoreSystem.CleanChainLanded += OnCleanChainLanded;
            AirTrickScoreSystem.OnFireActivated += OnFirstOnFireActivated;
        }

        private void OnDisable()
        {
            StrugglingSwimmerDrifter.SwimmerSaved -= OnSwimmerSaved;
            AirTrickScoreSystem.CleanChainLanded -= OnCleanChainLanded;
            AirTrickScoreSystem.OnFireActivated -= OnFirstOnFireActivated;
        }

        private IEnumerator Start()
        {
            // The title screen owns mode choice. Do not create a story ecosystem before Play/Continue.
            if (!GameModeSession.IsStory)
                yield break;

            yield return BeginRun(false);
            // Never overwrite an existing disk save merely because the title scene loaded.
            if (!SurfStageSaveSystem.HasSave)
                SurfStageSaveSystem.Save(this);

            //if (startOnDayTwoForTesting)
            //{
            //    StartCoroutine(BeginDayTwo());
            //    yield break;
            //}  
        }

        public IEnumerator RestartRunInPlace()
        {
            yield return BeginRun(true);
        }

        public IEnumerator StartNewRunFromMenu()
        {
            GameModeSession.SelectStoryMode();
            SurfStageSaveSystem.Delete();
            yield return BeginRun(true);
            SurfStageSaveSystem.Save(this);
        }

        public IEnumerator LoadSavedRun(SurfStageSaveSystem.SaveData data)
        {
            if (data == null) yield break;
            GameModeSession.SelectStoryMode();
            ClearRunObjects();
            yield return null;
            // Destroy() is deferred. Wait through the end of the frame so stale
            // boss instances cannot make the restored boss spawner abort.
            yield return new WaitForEndOfFrame();
            yield return null;

            float deadline = Time.realtimeSinceStartup + 12f;
            while ((EndlessWaveSections.Instance == null || !EndlessWaveSections.Instance.IsReady) &&
                   Time.realtimeSinceStartup < deadline)
                yield return null;

            currentDay = Mathf.Max(1, data.day);
            chapter = (Chapter)Mathf.Clamp(data.chapter, 0, (int)Chapter.Complete);
            runTime = Mathf.Max(0f, data.runTime);
            distanceTravelled = Mathf.Max(0f, data.distanceTravelled);
            hasPreviousPlayerX = false;
            rescues = Mathf.Max(0, data.rescues);
            finalWaveStarted = data.finalWaveStarted || chapter >= Chapter.FinalWave;
            bossDefeatedSunset = data.bossDefeatedSunset;
            changingDay = false;
            facilityEncounterStarted = false;
            banner = string.Empty;
            bannerUntil = 0f;
            rain = FindFirstObjectByType<ProceduralRainSystem>();
            rain?.ClearRain();
            AirTrickScoreSystem.Instance?.BeginDay(currentDay);
            AirTrickScoreSystem.Instance?.RestorePersistentStoke(data.totalStoke, data.dayStoke);
            if (SurfAbilityProgression.Instance != null)
            {
                if (data.unlockedAbilities != 0 || data.jumpUpgradeLevel != 0 ||
                    data.waterSlashUpgradeLevel != 0 || data.skidUpgradeLevel != 0)
                {
                    SurfAbilityProgression.Instance.RestoreExact(
                        (SurfAbility)data.unlockedAbilities,
                        data.jumpUpgradeLevel,
                        data.waterSlashUpgradeLevel,
                        data.skidUpgradeLevel);
                }
                else
                {
                    // Backward compatibility with saves created before staged abilities/upgrades.
                    SurfAbilityProgression.Instance.RestoreFor(currentDay, chapter);
                }

                // Day 2 is mastery-only: every core mechanic is always available,
                // including when continuing a save created by an older build.
                if (currentDay >= 2)
                    SurfAbilityProgression.Instance.DebugUnlockAll();

                // A save made after a developer chapter jump must contain every
                // mechanic that normal progression would have granted by this stage.
                SurfAbilityProgression.Instance.EnsureForStage(currentDay, chapter);
            }
            RefreshLearningObjectiveForStage();
            SyncDayNightToRunTime();

            // Continue can be selected before the normal press-to-spawn listener has
            // created Chuck. Restore or create the player first so any boss arena is
            // captured around the actual saved spawn position instead of scene zero.
            TinyWaveSurfer restoredPlayer = null;
            yield return EnsurePlayerReadyForLoadedRun(data, player => restoredPlayer = player);

            BoomboxSurferSpawner.RestoreForStage(
                currentDay,
                chapter,
                showHudNotice:
                    currentDay >= 2 || chapter >= Chapter.StrangeTide);

            SpawnPickupSet();
            SpawnOceanItems(12);
            RestoreChapterPopulation();

            if (currentDay == 4 && chapter != Chapter.Complete && restoredPlayer != null)
            {
                DayFourConspiracyEncounter.Begin(
                    this,
                    restoredPlayer,
                    data.dayFourIslandRevealed,
                    data.dayFourIslandDistance);
                SecretFacilityEncounter.BeginDayFourDisplay(restoredPlayer);
            }
            else if (currentDay == 5 && chapter != Chapter.Complete)
            {
                DayFiveEncounter.Begin(this);
            }
            else if (currentDay == 6 && chapter != Chapter.Complete)
            {
                DaySixEncounter.Begin(this);
            }

            if (chapter == Chapter.FinalWave)
            {
                yield return BuildBossEncounter(
                    rebuildExisting: false,
                    grantCompleteDeveloperLoadout: false,
                    showReadyBanner: false,
                    saveWhenReady: false);
            }

            RefreshLearningObjectiveForStage();
            SurfAbilityProgression.Instance?.ApplyUpgradesToAllPlayers();
            ShowBanner($"DAY {currentDay} CONTINUED", CurrentObjective, 4f);

            if (chapter == Chapter.Complete && !changingDay)
            {
                changingDay = true;
                if (currentDay == 4)
                    StartCoroutine(BeginDayFive());
                else if (currentDay == 5)
                    StartCoroutine(BeginDaySixSandbox());
            }
        }

        private IEnumerator EnsurePlayerReadyForLoadedRun(
            SurfStageSaveSystem.SaveData data,
            System.Action<TinyWaveSurfer> completed)
        {
            TinyWaveSurfer player = FindPlayerControlledSurfer();

            // A Continue load bypasses the normal press-to-spawn flow. Explicitly
            // create Chuck once the water world is ready so boss restoration never
            // depends on a later random input press.
            if (player == null)
            {
                TinyWaveSurferBootstrap.SpawnPlayerSurfer();

                float deadline = Time.realtimeSinceStartup + 5f;
                while (player == null && Time.realtimeSinceStartup < deadline)
                {
                    yield return null;
                    player = FindPlayerControlledSurfer();
                }
            }

            if (player == null)
            {
                Debug.LogError(
                    "Saved run could not restore Chuck before rebuilding the chapter.",
                    this);
                completed?.Invoke(null);
                yield break;
            }

            // Apply the saved lane and X position before any arena captures its
            // centre. Respawn first so death/disabled state cannot block placement.
            player.RespawnForManagedRun();
            yield return null;
            player.RestorePersistentState(data);
            GameplayTargetCache.Refresh();
            // Developer Mode is normally opened from the paused menu. A fixed
            // update never arrives while timeScale is zero, so do not let a day
            // jump stall forever waiting for one.
            if (Time.timeScale > 0f)
                yield return new WaitForFixedUpdate();
            else
                yield return null;
            BindStoryCamera(player);

            completed?.Invoke(player);
        }

        private static TinyWaveSurfer FindPlayerControlledSurfer()
        {
            foreach (TinyWaveSurfer surfer in FindObjectsByType<TinyWaveSurfer>(
                         FindObjectsInactive.Exclude,
                         FindObjectsSortMode.None))
            {
                if (surfer != null && surfer.IsPlayerControlled)
                    return surfer;
            }

            return null;
        }

        private static void BindStoryCamera(TinyWaveSurfer player)
        {
            if (player == null || Camera.main == null)
                return;

            Camera camera = Camera.main;
            BeachCameraFollow legacyFollow = camera.GetComponent<BeachCameraFollow>();
            if (legacyFollow != null)
            {
                legacyFollow.Target = null;
                legacyFollow.enabled = false;
            }

            TinySurferCinematicCamera follow = camera.GetComponent<TinySurferCinematicCamera>();
            if (follow != null)
            {
                follow.enabled = true;
                follow.SetFollowTarget(player, true);
            }
        }

        private void RestoreChapterPopulation()
        {
            if (currentDay == 6)
            {
                if (chapter == Chapter.Complete)
                {
                    objective = "THE SEVENTH CURRENT FOUND";
                    learningObjective = string.Empty;
                    return;
                }

                objective = chapter switch
                {
                    Chapter.Dawn => "LEAVE THE RESEARCH ISLAND BEHIND.",
                    Chapter.FirstRescue => "RESCUE THE LAST PROJECT HORIZON RESEARCHER.",
                    Chapter.DangerousWater => "SURVIVE THE IMPOSSIBLE WILDLIFE.",
                    Chapter.StrangeTide => "FOLLOW THE CREATURES INTO THE STARLIT CURRENT.",
                    Chapter.Storm => "RIDE THE SILENT SWELLS BEYOND THE MAP.",
                    Chapter.FinalWave => "FOLLOW THE SEVENTH CURRENT.",
                    _ => "SURF BEYOND THE KNOWN OCEAN."
                };
                learningObjective = string.Empty;
                DaySixEncounter.Begin(this);
                return;
            }

            if (currentDay >= 7)
            {
                objective = $"DAY {currentDay} DEVELOPMENT SANDBOX";
                learningObjective = string.Empty;
                return;
            }

            if (currentDay == 5)
            {
                if (chapter == Chapter.Complete)
                {
                    objective = "SECURITY NETWORK DISABLED";
                    learningObjective = string.Empty;
                    return;
                }

                objective = chapter switch
                {
                    Chapter.Dawn => "ENTER THE RESTRICTED SECURITY ZONE.",
                    Chapter.FirstRescue => "BREAK THROUGH THE DRONE AND BUOY PATROL.",
                    Chapter.DangerousWater => "DISABLE THE DRONE AND BUOY.",
                    Chapter.StrangeTide => "DODGE THE BUOY'S RED SKY BEAM.",
                    Chapter.Storm => "DISABLE THE SPECTRUM SIGNAL RELAY.",
                    Chapter.FinalWave => "DEFEAT THE WARDEN.",
                    _ => "ESCAPE THE SECURITY NETWORK."
                };
                DayFiveEncounter.Begin(this);
                if (chapter >= Chapter.Storm)
                    EnsureRain().SetSituation(ProceduralRainSystem.RainSituation.HeavyRain);
                return;
            }

            if (currentDay == 4)
            {
                if (chapter == Chapter.Complete)
                {
                    objective = "CLASSIFIED RESEARCH ISLAND FOUND";
                    learningObjective = string.Empty;
                    return;
                }

                objective = chapter switch
                {
                    Chapter.Dawn => "THE OUTPOST IS TRANSMITTING BEYOND THE WAVES.",
                    Chapter.FirstRescue => "RESCUE THE SWIMMER NEAR THE RESTRICTED ROUTE.",
                    Chapter.DangerousWater => "FOLLOW THE OUTPOST TRANSMISSION.",
                    Chapter.StrangeTide => "TRACK THE RECOVERY SIGNAL.",
                    Chapter.Storm => "KEEP THE SIGNAL THROUGH THE DISTORTED WEATHER.",
                    Chapter.FinalWave => "REACH THE CLASSIFIED ISLAND.",
                    _ => "FOLLOW THE TRANSMISSION."
                };
                SpawnMajor<WhaleLaneSpawner>("Restored Day Four Whale", spawner => spawner.SpawnWhale(true));
                SpawnMajor<StingrayLaneSpawner>("Restored Day Four Stingray", spawner => spawner.SpawnStingray(true));
                if (chapter >= Chapter.FirstRescue)
                    SpawnRescueSet(1);
                if (chapter >= Chapter.DangerousWater)
                {
                    SpawnMajor<TransparentSquidLaneSpawner>("Restored Day Four Squid", spawner => spawner.SpawnTransparentSquid(true));
                    SpawnMajor<BloodSharkLaneSpawner>("Restored Day Four Blood Shark", spawner => spawner.SpawnBloodShark(true));
                    SpawnMajor<StingrayLaneSpawner>("Restored Day Four Second Stingray", spawner => spawner.SpawnStingray(true));
                    SpawnRescueSet(2);
                }
                if (chapter >= Chapter.StrangeTide)
                {
                    SpawnUfo();
                    SpawnHelicopter();
                    SpawnBloodfishEncounter("Restored Day Four Bloodfish", 2);
                    SpawnMajor<TransparentSquidLaneSpawner>("Restored Day Four Veiled Squid", spawner => spawner.SpawnTransparentSquid(true));
                }
                if (chapter >= Chapter.Storm)
                {
                    EnsureRain().SetSituation(ProceduralRainSystem.RainSituation.HeavyRain);
                    SpawnMajor<BloodSharkLaneSpawner>("Restored Day Four Storm Blood Shark", spawner => spawner.SpawnBloodShark(true));
                    SpawnMajor<TransparentSquidLaneSpawner>("Restored Day Four Storm Squid", spawner => spawner.SpawnTransparentSquid(true));
                    SpawnMajor<StingrayLaneSpawner>("Restored Day Four Storm Stingray", spawner => spawner.SpawnStingray(true));
                    SpawnBloodfishEncounter("Restored Day Four Storm Bloodfish", 3);
                }
                return;
            }

            if (currentDay == 3)
            {
                objective = chapter switch
                {
                    Chapter.Dawn => "RIDE INTO THE RETURNING CURRENT.",
                    Chapter.FirstRescue => "SAVE THE FAMILIAR VOICE IN THE WATER.",
                    Chapter.DangerousWater => "SURVIVE THE THREATS THE OCEAN REMEMBERS.",
                    Chapter.StrangeTide => "WATCH THE SHADOW. KEEP MOVING FORWARD.",
                    Chapter.Storm => "FOLLOW THE SIGNAL THROUGH THE BLACK WATER.",
                    Chapter.FinalWave => "SURVIVE UNTIL THE OCEAN FALLS SILENT.",
                    _ => "SEARCH THE HORIZON."
                };
                if (chapter >= Chapter.FirstRescue) SpawnRescueSet(1);
                if (chapter >= Chapter.Storm)
                    EnsureRain().SetSituation(ProceduralRainSystem.RainSituation.HeavyRain);
                return;
            }

            bool dayTwo = currentDay == 2;
            if (!dayTwo)
            {
                objective = "Surf. Stay alive. Learn the water.";
                SpawnJellyfishEncounter("Dawn Jellyfish", 1);
                SpawnMajor<SharkLaneSpawner>("Early Shark", spawner => spawner.SpawnShark(true));
            }
            else
            {
                objective = "New predators have entered the water.";
                SpawnMajor<BloodSharkLaneSpawner>("Dawn Blood Shark", spawner => spawner.SpawnBloodShark(true));
                SpawnBloodfishEncounter("Dawn Bloodfish", 1);
            }

            if (chapter >= Chapter.FirstRescue) SpawnRescueSet(1);
            if (chapter >= Chapter.DangerousWater)
            {
                objective = $"RESCUES  {rescues}/{rescuesRequired}";
                if (!dayTwo)
                {
                    SpawnMajor<GiantSquidLaneSpawner>("First Squid", spawner => spawner.SpawnSquid(true));
                    SpawnMajor<SharkLaneSpawner>("Second Shark", spawner => spawner.SpawnShark(true));
                }
                else
                {
                    SpawnMajor<TransparentSquidLaneSpawner>("First Transparent Squid", spawner => spawner.SpawnTransparentSquid(true));
                    SpawnMajor<BloodSharkLaneSpawner>("Second Blood Shark", spawner => spawner.SpawnBloodShark(true));
                    SpawnMajor<StingrayLaneSpawner>("First Stingray", spawner => spawner.SpawnStingray(true));
                }
                SpawnRescueSet(Mathf.Max(1, rescuesRequired - rescues));
            }
            if (chapter >= Chapter.StrangeTide)
            {
                objective = "Something is watching the water.";
                SpawnBoombox();
                if (!dayTwo) { SpawnUfo(); SpawnJellyfishEncounter("Strange Tide Jellyfish", 2); SpawnMajor<WhaleLaneSpawner>("Strange Tide Whale", s => s.SpawnWhale(true)); }
                else { SpawnHelicopter(); SpawnBloodfishEncounter("Strange Tide Bloodfish", 2); SpawnMajor<TransparentSquidLaneSpawner>("Veiled Squid", s => s.SpawnTransparentSquid(true)); }
            }
            if (chapter >= Chapter.Storm)
            {
                objective = "Keep moving. Rescue anyone left out there.";
                EnsureRain().SetSituation(ProceduralRainSystem.RainSituation.HeavyRain);
                if (!dayTwo) { SpawnMajor<GiantSquidLaneSpawner>("Storm Squid", s => s.SpawnSquid(true)); SpawnJellyfishEncounter("Storm Jellyfish", 3); }
                else { SpawnMajor<BloodSharkLaneSpawner>("Storm Blood Shark", s => s.SpawnBloodShark(true)); SpawnMajor<TransparentSquidLaneSpawner>("Storm Transparent Squid", s => s.SpawnTransparentSquid(true)); SpawnMajor<StingrayLaneSpawner>("Storm Stingray", s => s.SpawnStingray(true)); SpawnBloodfishEncounter("Storm Bloodfish", 3); }
            }
            if (chapter >= Chapter.FinalWave)
            {
                objective = $"SURVIVE  {Mathf.Max(0, Mathf.CeilToInt(dayEndsAt - runTime))}s";
                // Boss construction is intentionally centralized in BuildBossEncounter.
                // LoadSavedRun calls it after ordinary population restoration has settled.
            }
        }

        private IEnumerator BeginRun(bool clearPreviousRun)
        {
            if (clearPreviousRun)
            {
                ClearRunObjects();
                yield return null; // allow deferred Destroy calls to finish
            }

            float deadline = Time.realtimeSinceStartup + 12f;
            while ((EndlessWaveSections.Instance == null || !EndlessWaveSections.Instance.IsReady) &&
                   Time.realtimeSinceStartup < deadline)
                yield return null;

            TinyWaveSurferBootstrap.ResetSpawnState();
            TinyWaveSurferBootstrap.SpawnPlayerSurfer();
            TinyWaveSurfer storyPlayer = null;
            float playerDeadline = Time.realtimeSinceStartup + 5f;
            while (storyPlayer == null && Time.realtimeSinceStartup < playerDeadline)
            {
                storyPlayer = FindPlayerControlledSurfer();
                if (storyPlayer == null)
                    yield return null;
            }

            if (storyPlayer == null)
            {
                Debug.LogError("Fresh Story run could not create Chuck before population setup.", this);
                yield break;
            }

            BindStoryCamera(storyPlayer);
            GameplayTargetCache.Refresh();

            runTime = 0f;
            distanceTravelled = 0f;
            hasPreviousPlayerX = false;
            currentDay = 1; // 1
            changingDay = false;
            rescues = 0;
            finalWaveStarted = false;
            bossDefeatedSunset = false;
            AirTrickScoreSystem.Instance?.BeginDay(1);
            SurfAbilityProgression.Instance?.ResetForNewRun();
            chapter = Chapter.Dawn;
            banner = string.Empty;
            objective = string.Empty;
            learningObjective = string.Empty;
            bannerUntil = 0f;

            rain = FindFirstObjectByType<ProceduralRainSystem>();
            rain?.ClearRain();
            SyncDayNightToRunTime();
            SpawnPickupSet();
            SpawnOceanItems(12);
            if (currentDay == 1)
            {
                BeginChapter(Chapter.Dawn, "DAWN PATROL", "SURF. STAY ALIVE. LEARN THE WATER.");

                SpawnJellyfishEncounter("Dawn Jellyfish", 1);
                SpawnMajor<SharkLaneSpawner>("Early Shark", spawner => spawner.SpawnShark(true));
            }
            else
            {
                BeginChapter(Chapter.Dawn, "DAY 2 — DEEP CURRENT", "NEW PREDATORS HAVE ENTERED THE WATER.");
                SpawnMajor<BloodSharkLaneSpawner>("Dawn Blood Shark", spawner => spawner.SpawnBloodShark(true));
                SpawnBloodfishEncounter("Dawn Bloodfish", 1);
            }
        }


        private IEnumerator BeginDayTwo()
        {
            AirTrickScoreSystem.Instance?.ShowDayRecap(1, 5f);
            yield return new WaitForSecondsRealtime(5f);
            if (SurfDayUpgradeScreen.Instance != null)
                yield return SurfDayUpgradeScreen.Instance.ShowAndWait();

            ShowBanner("NIGHT PASSES", "DAY 2 — DEEP CURRENT", 4f);
            rain?.ClearRain();
            yield return new WaitForSeconds(4f);

            foreach (GameObject holder in progressionSpawners)
                if (holder != null) Destroy(holder);
            progressionSpawners.Clear();
            DestroyAll<SharkLaneSwimmer>();
            DestroyAll<GiantSquidLaneSwimmer>();
            DestroyAll<GodzillaLaneSwimmer>();
            DestroyAll<JellyfishSwimmer>();
            DestroyAll<BloodfishSwimmer>();
            DestroyAll<BloodSharkLaneSwimmer>();
            DestroyAll<TransparentSquidLaneSwimmer>();
            DestroyAll<StingrayLaneSwimmer>();
            DestroyAll<DayTwoHelicopterController>();
            DestroyAll<DayTwoHelicopterMissile>();
            DestroyAll<RubberDuckBossSwimmer>();
            DestroyAll<RubberDucklingSwimmer>();
            yield return null;

            // The world stays paused behind the cutscene system's full black fade.
            // Day 2 enemies are not spawned until all six boards have finished.
            yield return StoryboardCutsceneSystem.PlayDayTwoOpening();

            currentDay = 2;
            AirTrickScoreSystem.Instance?.BeginDay(2);
            SurfAbilityProgression.Instance?.DebugUnlockAll();
            runTime = 0f;
            distanceTravelled = 0f;
            hasPreviousPlayerX = false;
            SyncDayNightToRunTime();
            rescues = 0;
            finalWaveStarted = false;
            bossDefeatedSunset = false;
            chapter = Chapter.Dawn;
            changingDay = false;
            BeginChapter(Chapter.Dawn, "DAY 2 — DEEP CURRENT", "NEW PREDATORS HAVE ENTERED THE WATER.");
            learningObjective = "Use the full moveset to build flow and survive.";
            SpawnPickupSet();
            SpawnOceanItems(12);
            SpawnMajor<BloodSharkLaneSpawner>("Dawn Blood Shark", spawner => spawner.SpawnBloodShark(true));
            SpawnBloodfishEncounter("Dawn Bloodfish", 1);
            SurfStageSaveSystem.Save(this);
        }

        private IEnumerator BeginDayThree()
        {
            AirTrickScoreSystem.Instance?.ShowDayRecap(2, 5f);
            yield return new WaitForSecondsRealtime(5f);
            if (SurfDayUpgradeScreen.Instance != null)
                yield return SurfDayUpgradeScreen.Instance.ShowAndWait();

            ShowBanner("THE NIGHT DOES NOT PASS", "DAY 3 — THE OCEAN REMEMBERS", 4f);
            rain?.ClearRain();
            yield return new WaitForSecondsRealtime(3f);

            ClearRunObjects();
            yield return null;

            // Keep the cleared ocean frozen behind the storyboard. Day 3 state,
            // the Shadow Surfer, enemies and pickups begin only after all three
            // boards and their dialogue have finished.
            yield return StoryboardCutsceneSystem.PlayDayThreeOpening();

            currentDay = 3;
            AirTrickScoreSystem.Instance?.BeginDay(3);
            SurfAbilityProgression.Instance?.DebugUnlockAll();
            runTime = 0f;
            distanceTravelled = 0f;
            hasPreviousPlayerX = false;
            rescues = 0;
            finalWaveStarted = false;
            bossDefeatedSunset = false;
            chapter = Chapter.Dawn;
            changingDay = false;
            SyncDayNightToRunTime();
            BeginChapter(Chapter.Dawn, "DAY 3 — THE OCEAN REMEMBERS", "RIDE INTO THE RETURNING CURRENT.");
            learningObjective = "Notice what the ocean brings back.";
            SpawnPickupSet();
            SpawnOceanItems(12);
            SurfStageSaveSystem.Save(this);
        }

        private void ClearRunObjects()
        {
            if (pendingBossEncounter != null)
            {
                StopCoroutine(pendingBossEncounter);
                pendingBossEncounter = null;
            }

            BoomboxSurferSpawner.LockAndRelease();
            foreach (GameObject holder in progressionSpawners)
                if (holder != null) Destroy(holder);
            progressionSpawners.Clear();

            DestroyAll<SharkLaneSwimmer>();
            DestroyAll<GiantSquidLaneSwimmer>();
            DestroyAll<BloodSharkLaneSwimmer>();
            DestroyAll<TransparentSquidLaneSwimmer>();
            DestroyAll<StingrayLaneSwimmer>();
            DestroyAll<GodzillaLaneSwimmer>();
            DestroyAll<GodzillaSkullSwimmer>();
            DestroyAll<JellyfishSwimmer>();
            DestroyAll<BloodfishSwimmer>();
            DestroyAll<WhaleLaneSwimmer>();
            DestroyAll<GiantTurtleSwimmer>();
            DestroyAll<SeaTurtleSwimmer>();
            DestroyAll<ShadowSurferEcho>();
            DestroyAll<StrugglingSwimmerDrifter>();
            DestroyAll<RescuedSurferExit>();
            DestroyAll<OceanItemBehaviour>();
            DestroyAll<SodaCanPickup>();
            DestroyAll<SodaCanProjectile>();
            DestroyAll<AlienUfoController>();
            DestroyAll<DayTwoHelicopterController>();
            DestroyAll<DayTwoHelicopterMissile>();
            DestroyAll<RubberDuckBossSwimmer>();
            DestroyAll<RubberDucklingSwimmer>();
            DestroyAll<BoomboxSurferSwimmer>();
            DestroyAll<BossArenaPrison>();
            DestroyAll<SecretFacilityEncounter>();
            DestroyAll<DayFourConspiracyEncounter>();
            DestroyAll<DayFiveCombatant>();
            DestroyAll<DayFiveWardenMissile>();
            DestroyAll<DayFiveSecurityPulse>();
            DestroyAll<DayFiveSecurityImpact>();
            DestroyAll<DayFiveEncounter>();
            DestroyAll<DaySixCreature>();
            DestroyAll<DaySixHazardProjectile>();
            DestroyAll<DaySixEncounter>();
            ambientThreatDay = -1;
            nextAmbientThreatAt = 0f;
        }

        private static void DestroyAll<T>() where T : Component
        {
            foreach (T item in FindObjectsByType<T>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (item != null) Destroy(item.gameObject);
            }
        }

        public void CompleteDayThreeAtFacility()
        {
            if (currentDay != 3 || chapter == Chapter.Complete)
                return;

            facilityEncounterStarted = false;
            BeginChapter(Chapter.Complete,
                "DAY 3 COMPLETE",
                "YOU FOUND WHAT WAS HIDDEN BEYOND THE WAVES.");
            objective = "SECRET FACILITY DISCOVERED";
            learningObjective = string.Empty;
            AirTrickScoreSystem.Instance?.ShowDayRecap(3, 10f);
            rain?.ClearRain();
            QueueCheckpoint();

            if (!changingDay)
            {
                changingDay = true;
                StartCoroutine(BeginDayFour());
            }
        }

        private IEnumerator BeginDayFour()
        {
            yield return new WaitForSecondsRealtime(10f);
            if (SurfDayUpgradeScreen.Instance != null)
                yield return SurfDayUpgradeScreen.Instance.ShowAndWait();

            ShowBanner("THE SIGNAL CONTINUES", "DAY 4 — PROJECT HORIZON", 4f);
            rain?.ClearRain();
            yield return new WaitForSecondsRealtime(3f);

            ClearRunObjects();
            DestroyAll<SecretFacilityEncounter>();
            DestroyAll<DayThreeOceanRemembers>();
            DestroyAll<DayFourConspiracyEncounter>();
            yield return null;

            // Keep the cleared ocean frozen behind the five-board Day 4 opening.
            // Day 4 world objects and encounters are created only after it finishes.
            yield return StoryboardCutsceneSystem.PlayDayFourOpening();

            currentDay = 4;
            AirTrickScoreSystem.Instance?.BeginDay(4);
            SurfAbilityProgression.Instance?.DebugUnlockAll();
            runTime = 0f;
            distanceTravelled = 0f;
            hasPreviousPlayerX = false;
            rescues = 0;
            finalWaveStarted = false;
            bossDefeatedSunset = false;
            chapter = Chapter.Dawn;
            changingDay = false;
            facilityEncounterStarted = false;
            SyncDayNightToRunTime();
            BeginChapter(Chapter.Dawn,
                "DAY 4 — PROJECT HORIZON",
                "THE OUTPOST IS TRANSMITTING SOMEWHERE BEYOND THE WAVES.");
            learningObjective = "Stay near the signal and watch the horizon.";
            SpawnPickupSet();
            SpawnOceanItems(12);
            SpawnMajor<WhaleLaneSpawner>("Day Four Dawn Whale", spawner => spawner.SpawnWhale(true));
            SpawnMajor<StingrayLaneSpawner>("Day Four Dawn Stingray", spawner => spawner.SpawnStingray(true));

            TinyWaveSurfer surfer = FindPlayerControlledSurfer();
            if (surfer != null)
            {
                DayFourConspiracyEncounter.Begin(this, surfer);
                SecretFacilityEncounter.BeginDayFourDisplay(surfer);
            }

            SurfStageSaveSystem.Save(this);
        }

        public void AnnounceDayFourIsland()
        {
            if (currentDay != 4 || chapter == Chapter.Complete)
                return;

            objective = "FOLLOW THE TRANSMISSION TO THE ISLAND";
            learningObjective = string.Empty;
            ShowBanner("THE SOURCE", "A CLASSIFIED ISLAND EMERGES ON THE HORIZON.", 5f);
            QueueCheckpoint();
        }

        public void CompleteDayFourAtIsland()
        {
            if (currentDay != 4 || chapter == Chapter.Complete)
                return;

            BeginChapter(Chapter.Complete,
                "DAY 4 COMPLETE",
                "THE OUTPOST LEADS TO A FACILITY THAT DOES NOT EXIST.");
            objective = "CLASSIFIED RESEARCH ISLAND FOUND";
            learningObjective = string.Empty;
            AirTrickScoreSystem.Instance?.ShowDayRecap(4, 10f);
            rain?.ClearRain();
            QueueCheckpoint();

            if (!changingDay)
            {
                changingDay = true;
                StartCoroutine(BeginDayFive());
            }
        }

        private IEnumerator BeginDayFive()
        {
            yield return new WaitForSecondsRealtime(10f);
            if (SurfDayUpgradeScreen.Instance != null)
                yield return SurfDayUpgradeScreen.Instance.ShowAndWait();

            ShowBanner("ACCESS DENIED", "DAY 5 — RED HORIZON", 4f);
            rain?.ClearRain();
            yield return new WaitForSecondsRealtime(3f);

            ClearRunObjects();
            DestroyAll<DayFourConspiracyEncounter>();
            DestroyAll<SecretFacilityEncounter>();
            yield return null;

            currentDay = 5;
            AirTrickScoreSystem.Instance?.BeginDay(5);
            SurfAbilityProgression.Instance?.DebugUnlockAll();
            runTime = 0f;
            distanceTravelled = 0f;
            hasPreviousPlayerX = false;
            rescues = 0;
            finalWaveStarted = false;
            bossDefeatedSunset = false;
            chapter = Chapter.Dawn;
            changingDay = false;
            facilityEncounterStarted = false;
            SyncDayNightToRunTime();
            BeginChapter(
                Chapter.Dawn,
                "DAY 5 — RED HORIZON",
                "ENTER THE RESTRICTED ZONE. WATCH FOR SEARCH BEAMS.");
            learningObjective = "Dodge telegraphed beams and attack the security units.";
            SpawnPickupSet();
            SpawnOceanItems(12);
            DayFiveEncounter.Begin(this);
            SurfStageSaveSystem.Save(this);
        }

        public void CompleteDayFive()
        {
            if (currentDay != 5 || chapter == Chapter.Complete)
                return;

            FindFirstObjectByType<DayFiveEncounter>()?.EndEncounter();
            bossDefeatedSunset = true;
            BeginChapter(
                Chapter.Complete,
                "DAY 5 COMPLETE",
                "THE WARDEN IS OFFLINE. THE RED HORIZON GOES DARK.");
            objective = "SECURITY NETWORK DISABLED";
            learningObjective = string.Empty;
            AirTrickScoreSystem.Instance?.ShowDayRecap(5, 10f);
            rain?.ClearRain();
            QueueCheckpoint();

            if (!changingDay)
            {
                changingDay = true;
                StartCoroutine(BeginDaySixSandbox());
            }
        }

        private IEnumerator BeginDaySixSandbox()
        {
            yield return new WaitForSecondsRealtime(10f);
            if (SurfDayUpgradeScreen.Instance != null)
                yield return SurfDayUpgradeScreen.Instance.ShowAndWait();

            ShowBanner("SECURITY GRID CLEARED", "DAY 6 — BEYOND THE HORIZON", 4f);
            rain?.ClearRain();
            yield return new WaitForSecondsRealtime(3f);

            ClearRunObjects();
            yield return null;

            currentDay = 6;
            AirTrickScoreSystem.Instance?.BeginDay(6);
            SurfAbilityProgression.Instance?.DebugUnlockAll();
            runTime = 0f;
            distanceTravelled = 0f;
            hasPreviousPlayerX = false;
            rescues = 0;
            finalWaveStarted = false;
            bossDefeatedSunset = false;
            chapter = Chapter.Dawn;
            changingDay = false;
            facilityEncounterStarted = false;
            SyncDayNightToRunTime();
            BeginChapter(
                Chapter.Dawn,
                "DAY 6 — BEYOND THE HORIZON",
                "THE MAP ENDS HERE. THE CURRENT DOES NOT.");
            learningObjective = "Every oddity swims inside the familiar wave lanes, but none attacks the same way.";
            SpawnPickupSet();
            SpawnOceanItems(12);
            DaySixEncounter.Begin(this);
            SurfStageSaveSystem.Save(this);
        }

        public void CompleteDaySix()
        {
            if (currentDay != 6 || chapter == Chapter.Complete)
                return;

            FindFirstObjectByType<DaySixEncounter>()?.EndEncounter();
            bossDefeatedSunset = true;
            BeginChapter(
                Chapter.Complete,
                "DAY 6 COMPLETE",
                "YOU HAVE LEFT THE KNOWN OCEAN.");
            objective = "THE SEVENTH CURRENT FOUND";
            learningObjective = string.Empty;
            AirTrickScoreSystem.Instance?.ShowDayRecap(6, 10f);
            rain?.ClearRain();
            QueueCheckpoint();
        }

        private void UpdateProgressiveAtmosphere()
        {
            if (Time.unscaledTime < nextAtmosphereRefreshTime)
                return;

            nextAtmosphereRefreshTime = Time.unscaledTime + 0.35f;

            float progress = NormalizedDayProgress;
            bool stormActive = chapter >= Chapter.Storm;

            ProceduralRainSystem.RainSituation desiredWeather;
            if (stormActive || progress >= 0.76f)
                desiredWeather = ProceduralRainSystem.RainSituation.HeavyRain;
            else if (progress >= 0.60f)
                desiredWeather = ProceduralRainSystem.RainSituation.WindDrivenRain;
            else if (progress >= 0.43f)
                desiredWeather = ProceduralRainSystem.RainSituation.SteadyRain;
            else if (progress >= 0.27f)
                desiredWeather = ProceduralRainSystem.RainSituation.LightRain;
            else
                desiredWeather = ProceduralRainSystem.RainSituation.Clear;

            ProceduralRainSystem weather = EnsureRain();
            if (desiredWeather != appliedProgressionWeather ||
                weather.CurrentSituation != desiredWeather)
            {
                appliedProgressionWeather = desiredWeather;
                weather.SetSituation(desiredWeather);
            }

            foreach (PixelWaterGPU water in FindObjectsByType<PixelWaterGPU>(
                         FindObjectsInactive.Exclude,
                         FindObjectsSortMode.None))
            {
                if (water != null)
                    water.SetStoryWaveProgress(progress, currentDay, stormActive);
            }
        }

        private void UpdateProgressiveHostileSpawns()
        {
            if (ambientThreatDay != currentDay)
            {
                ambientThreatDay = currentDay;
                ScheduleNextAmbientThreat(true);
            }

            // Day 3 already owns a progressive remix spawner. Final waves hand
            // the arena to the chapter boss, and Days 6–7 remain clean sandboxes.
            if (currentDay == 3 || currentDay >= 6 ||
                chapter < Chapter.DangerousWater || chapter >= Chapter.FinalWave)
                return;

            if (Time.time < nextAmbientThreatAt)
                return;

            ScheduleNextAmbientThreat(false);

            int cap = currentDay == 5
                ? Mathf.Max(2, maximumAmbientHostiles - 2)
                : maximumAmbientHostiles;
            if (CountLivingAmbientHostiles() >= cap)
                return;

            SpawnAmbientHostile();
        }

        private void ScheduleNextAmbientThreat(bool firstForDay)
        {
            float pressure = Mathf.Clamp01(Mathf.InverseLerp(
                0.20f,
                0.88f,
                NormalizedDayProgress));
            float centre = Mathf.Lerp(
                Mathf.Max(busiestThreatInterval, quietestThreatInterval),
                Mathf.Min(busiestThreatInterval, quietestThreatInterval),
                pressure);

            if (currentDay == 5)
                centre *= 1.18f;
            if (firstForDay)
                centre *= 1.15f;

            nextAmbientThreatAt = Time.time + Random.Range(
                centre * 0.82f,
                centre * 1.18f);
        }

        private static int CountLivingAmbientHostiles()
        {
            return FindObjectsByType<SharkLaneSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length +
                   FindObjectsByType<GiantSquidLaneSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length +
                   FindObjectsByType<JellyfishSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length +
                   FindObjectsByType<BloodSharkLaneSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length +
                   FindObjectsByType<TransparentSquidLaneSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length +
                   FindObjectsByType<StingrayLaneSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length +
                   FindObjectsByType<BloodfishSwimmer>(
                       FindObjectsInactive.Exclude, FindObjectsSortMode.None).Length;
        }

        private void SpawnAmbientHostile()
        {
            if (currentDay == 1)
            {
                switch (Random.Range(0, 3))
                {
                    case 0:
                        SpawnMajor<SharkLaneSpawner>(
                            "Roaming Shark",
                            spawner => spawner.SpawnShark(true));
                        break;
                    case 1:
                        SpawnMajor<GiantSquidLaneSpawner>(
                            "Roaming Giant Squid",
                            spawner => spawner.SpawnSquid(true));
                        break;
                    default:
                        SpawnJellyfishEncounter("Roaming Jellyfish", 1);
                        break;
                }
                return;
            }

            int variants = currentDay == 5 ? 3 : 4;
            switch (Random.Range(0, variants))
            {
                case 0:
                    SpawnMajor<BloodSharkLaneSpawner>(
                        $"Day {currentDay} Roaming Blood Shark",
                        spawner => spawner.SpawnBloodShark(true));
                    break;
                case 1:
                    SpawnMajor<TransparentSquidLaneSpawner>(
                        $"Day {currentDay} Roaming Transparent Squid",
                        spawner => spawner.SpawnTransparentSquid(true));
                    break;
                case 2:
                    SpawnMajor<StingrayLaneSpawner>(
                        $"Day {currentDay} Roaming Stingray",
                        spawner => spawner.SpawnStingray(true));
                    break;
                default:
                    SpawnBloodfishEncounter($"Day {currentDay} Roaming Bloodfish", 1);
                    break;
            }
        }

        private void Update()
        {
            if (developerDaySwitchInProgress || chapter == Chapter.Complete ||
                EndlessWaveSections.Instance == null)
                return;

            TinyWaveSurfer player = FindPlayerControlledSurfer();
            if (player == null || player.IsDead)
                return;

            if (currentDay == 4 && chapter != Chapter.Complete &&
                Time.unscaledTime >= nextDayFourEncounterCheck)
            {
                nextDayFourEncounterCheck = Time.unscaledTime + 1f;
                DayFourConspiracyEncounter.Begin(this, player);
                SecretFacilityEncounter.BeginDayFourDisplay(player);
            }

            if (chapter == Chapter.FinalWave &&
                Time.unscaledTime >= nextFinalEncounterRecoveryCheck)
            {
                nextFinalEncounterRecoveryCheck = Time.unscaledTime + 1.5f;
                RecoverMissingFinalEncounter(player);
            }

            runTime += Time.deltaTime;
            TrackJourneyDistance(player);
            SyncDayNightToRunTime();
            UpdateProgressiveAtmosphere();
            UpdateProgressiveHostileSpawns();
            UpdateDayOneMechanicUnlocks();

            if (currentDay == 5 && chapter == Chapter.FinalWave &&
                runTime >= dayEndsAt)
            {
                CompleteDayFive();
                return;
            }

            bool reachedJourneyEnd = distanceTravelled >=
                GetDistanceThresholdForChapter(Chapter.Complete);
            bool reachedDayThreeTimedEnd = currentDay == 3 &&
                runTime >= dayEndsAt;

            if (finalWaveStarted && (reachedJourneyEnd || reachedDayThreeTimedEnd))
            {
                if (currentDay == 1 && !changingDay)
                {
                    changingDay = true;
                    StartCoroutine(BeginDayTwo());
                }
                else if (currentDay == 2 && !changingDay)
                {
                    changingDay = true;
                    StartCoroutine(BeginDayThree());
                }
                else if (currentDay == 3)
                {
                    EnsureDayThreeFacility(player);
                }
                else if (currentDay == 6)
                {
                    CompleteDaySix();
                }
                else if (currentDay >= 7)
                {
                    objective = $"DAY {currentDay} DEVELOPMENT SANDBOX";
                    learningObjective = string.Empty;
                }
                else if (currentDay >= 4)
                {
                    objective = currentDay == 5
                        ? "SECURITY NETWORK DISABLED"
                        : "REACH THE CLASSIFIED ISLAND";
                    learningObjective = string.Empty;
                }
                return;
            }

            bool finalWaveGateOpen = currentDay != 5 ||
                (chapter == Chapter.Storm &&
                 DayFiveEncounter.Begin(this)?.CanAdvanceFromSignalRelay == true);
            if ((distanceTravelled >= GetDistanceThresholdForChapter(Chapter.FinalWave) ||
                 runTime >= finalWaveBeginsAt) &&
                chapter < Chapter.FinalWave &&
                finalWaveGateOpen)
            {
                finalWaveStarted = true;
                BeginChapter(Chapter.FinalWave,
                    currentDay == 6 ? "THE SEVENTH CURRENT" : currentDay == 5 ? "THE WARDEN" : currentDay == 4 ? "THE ISLAND ON THE HORIZON" : currentDay == 3 ? "THE LAST ECHO" : currentDay == 2 ? "DUCK STORM" : "THE LAST WAVE",
                    currentDay == 6 ? "FOLLOW THE IMPOSSIBLE MIGRATION BEYOND THE MAP." : currentDay == 5 ? "DEFEAT THE WARDEN." : currentDay == 4 ? "FOLLOW THE TRANSMISSION TO ITS SOURCE." : currentDay == 3 ? "SURVIVE UNTIL THE OCEAN FALLS SILENT." : currentDay == 2 ? "BREAK THROUGH THE ARMOURED FLOCK." : $"SURVIVE {finalSurvivalSeconds} SECONDS.");
                if (pendingBossEncounter == null)
                {
                    pendingBossEncounter = StartCoroutine(
                        BuildBossEncounter(
                            rebuildExisting: false,
                            grantCompleteDeveloperLoadout: false,
                            showReadyBanner: false,
                            saveWhenReady: true));
                }
                return;
            }

            if ((distanceTravelled >= GetDistanceThresholdForChapter(Chapter.Storm) ||
                 runTime >= stormBeginsAt) && chapter < Chapter.Storm)
            {
                BeginChapter(Chapter.Storm,
                    currentDay == 6 ? "THE SILENT SWELL" : currentDay == 5 ? "SPECTRUM RELAY" : currentDay == 4 ? "ENCRYPTED WEATHER" : currentDay == 3 ? "SIGNAL IN THE STORM" : currentDay == 2 ? "RED WEATHER" : "STORM FRONT",
                    currentDay == 6 ? "THE WIND IS GONE. EVERY WAVE IS MOVING THE SAME WAY." : currentDay == 5 ? "DISABLE THE SIGNAL RELAY AND DODGE ITS ANGLED SPECTRUM." : currentDay == 4 ? "THE TRANSMISSION IS DISTORTING THE SEA AND SKY." : currentDay == 3 ? "FOLLOW THE DISTANT LIGHT THROUGH THE BLACK WATER." : currentDay == 2 ? "OUTRUN THE HUNTERS ABOVE AND BELOW." : "KEEP MOVING. RESCUE ANYONE LEFT OUT THERE.");
                EnsureRain().SetSituation(ProceduralRainSystem.RainSituation.HeavyRain);
                if (currentDay < 5)
                {
                    if (currentDay == 1)
                        SpawnMajor<GiantSquidLaneSpawner>("Storm Squid", spawner => spawner.SpawnSquid(true));
                    else
                    {
                        SpawnMajor<BloodSharkLaneSpawner>("Storm Blood Shark", spawner => spawner.SpawnBloodShark(true));
                        SpawnMajor<TransparentSquidLaneSpawner>("Storm Transparent Squid", spawner => spawner.SpawnTransparentSquid(true));
                        SpawnMajor<StingrayLaneSpawner>("Storm Stingray", spawner => spawner.SpawnStingray(true));
                    }
                    if (currentDay == 1)
                        SpawnJellyfishEncounter("Storm Jellyfish", 3);
                    else
                        SpawnBloodfishEncounter("Storm Bloodfish", 3);
                }
                return;
            }

            if ((distanceTravelled >= GetDistanceThresholdForChapter(Chapter.StrangeTide) ||
                 runTime >= strangeTideBeginsAt) && chapter < Chapter.StrangeTide)
            {
                BeginChapter(Chapter.StrangeTide,
                    currentDay == 6 ? "STARS BELOW" : currentDay == 5 ? "RED SKY" : currentDay == 4 ? "RECOVERY SIGNAL" : currentDay == 3 ? "THE SHADOW RETURNS" : currentDay == 2 ? "EYES IN THE SKY" : "STRANGE TIDE",
                    currentDay == 6 ? "THE WATER IS REFLECTING A NIGHT THAT HAS NOT HAPPENED." : currentDay == 5 ? "THE DRONE AND BUOY HAVE YOUR POSITION." : currentDay == 4 ? "ALIEN MACHINERY IS ACTIVE BENEATH THE TRANSMISSION." : currentDay == 3 ? "IT COPIES YOU. DO NOT LET IT TURN YOU BACK." : currentDay == 2 ? "THE HELICOPTER HAS LOCKED ON." : "SOMETHING IS WATCHING THE WATER.");
                if (currentDay == 1)
                    UnlockAbility(SurfAbility.Rotation | SurfAbility.Flip |
                        SurfAbility.DoubleChain | SurfAbility.TripleChain,
                        "FULL TRICK CHAINS UNLOCKED",
                        "CHAIN EACH UNIQUE AIR TRICK ONCE BEFORE LANDING.");
                if (currentDay < 5)
                {
                    SpawnBoombox();
                    if (currentDay == 1)
                        SpawnUfo();
                    else if (currentDay == 2)
                        SpawnHelicopter();
                    else if (currentDay == 4)
                    {
                        SpawnUfo();
                        SpawnHelicopter();
                    }
                    if (currentDay == 1)
                        SpawnJellyfishEncounter("Strange Tide Jellyfish", 2);
                    else
                        SpawnBloodfishEncounter("Strange Tide Bloodfish", 2);
                    if (currentDay == 1)
                        SpawnMajor<WhaleLaneSpawner>("Strange Tide Whale", spawner => spawner.SpawnWhale(true));
                    else
                        SpawnMajor<TransparentSquidLaneSpawner>("Veiled Squid", spawner => spawner.SpawnTransparentSquid(true));
                }
                return;
            }

            if ((distanceTravelled >= GetDistanceThresholdForChapter(Chapter.DangerousWater) ||
                 runTime >= dangerBeginsAt) && chapter < Chapter.DangerousWater)
            {
                BeginChapter(Chapter.DangerousWater,
                    currentDay == 6 ? "IMPOSSIBLE WILDLIFE" : currentDay == 5 ? "SHARED WAVE LOCK" : currentDay == 4 ? "CLASSIFIED CURRENT" : currentDay == 3 ? "MEMORY CURRENT" : currentDay == 2 ? "BLOOD CURRENT" : "DANGEROUS WATER",
                    currentDay == 6 ? "LEARN EACH CREATURE'S LANE PATTERN." : currentDay == 5 ? "THE DRONE AND BUOY ARE SHARING THE WAVE GRID." : currentDay == 4 ? "THE OUTPOST SIGNAL IS DRAWING PREDATORS AND MACHINES." : currentDay == 3 ? "OLD THREATS RETURN IN THE WRONG ORDER." : currentDay == 2 ? "SURVIVE THE NEW PREDATORS." : "SAVE 3 SWIMMERS. USE CANS TO FIGHT BACK.");
                if (currentDay == 1)
                    UnlockAbility(SurfAbility.ChargedJump,
                        "CHARGED JUMP UNLOCKED",
                        "HOLD JUMP WHILE MOVING, THEN RELEASE TO LAUNCH.");
                if (currentDay == 1)
                {
                    SpawnMajor<GiantSquidLaneSpawner>("First Squid", spawner => spawner.SpawnSquid(true));
                    SpawnMajor<SharkLaneSpawner>("Second Shark", spawner => spawner.SpawnShark(true));
                }
                else if (currentDay < 5)
                {
                    SpawnMajor<TransparentSquidLaneSpawner>("First Transparent Squid", spawner => spawner.SpawnTransparentSquid(true));
                    SpawnMajor<BloodSharkLaneSpawner>("Second Blood Shark", spawner => spawner.SpawnBloodShark(true));
                    SpawnMajor<StingrayLaneSpawner>("First Stingray", spawner => spawner.SpawnStingray(true));
                }
                if (currentDay < 5)
                    SpawnRescueSet(2);
                return;
            }

            if ((distanceTravelled >= GetDistanceThresholdForChapter(Chapter.FirstRescue) ||
                 runTime >= rescueBeginsAt) && chapter < Chapter.FirstRescue)
            {
                BeginChapter(Chapter.FirstRescue,
                    currentDay == 6 ? "THE LAST WARNING" : currentDay == 5 ? "SECURITY NET" : currentDay == 4 ? "NO AUTHORIZED TRAFFIC" : currentDay == 3 ? "A FAMILIAR VOICE" : currentDay == 2 ? "AFTER THE WRECK" : "DISTRESS CALL",
                    currentDay == 6 ? "RESCUE THE RESEARCHER CARRYING THE FINAL HORIZON RECORD." : currentDay == 5 ? "BREAK THROUGH THE DRONE AND BUOY PATROL." : currentDay == 4 ? "RESCUE THE SWIMMER CAUGHT NEAR THE RESTRICTED ROUTE." : currentDay == 3 ? "SAVE THE SWIMMER THE OCEAN BROUGHT BACK." : currentDay == 2 ? "PULL THE SURVIVOR OUT OF THE DEEP CURRENT." : "FIND AND SAVE THE STRUGGLING SWIMMER.");
                SpawnRescueSet(1);
            }

            if (chapter == Chapter.DangerousWater)
                objective = currentDay == 6
                    ? "SURVIVE THE IMPOSSIBLE WILDLIFE."
                    : currentDay == 5
                    ? "DISABLE THE DRONE AND BUOY."
                    : currentDay == 4
                    ? "FOLLOW THE OUTPOST TRANSMISSION."
                    : currentDay == 3
                        ? "SURVIVE THE THREATS THE OCEAN REMEMBERS."
                        : $"RESCUES  {rescues}/{rescuesRequired}";
            else if (chapter == Chapter.FinalWave)
                objective = currentDay == 6
                    ? $"SEVENTH CURRENT  {Mathf.Max(0, Mathf.CeilToInt(DayDistance - distanceTravelled))} m"
                    : currentDay == 5
                    ? "DEFEAT THE WARDEN"
                    : currentDay == 4
                    ? $"ISLAND SIGNAL  {Mathf.Max(0, Mathf.CeilToInt(dayEndsAt - runTime))}s"
                    : currentDay == 3
                        ? $"LAST ECHO  {Mathf.Max(0, Mathf.CeilToInt(dayEndsAt - runTime))}s"
                        : bossDefeatedSunset
                        ? $"SUNSET RUN  {Mathf.Max(0, Mathf.CeilToInt(DayDistance - distanceTravelled))} m"
                        : $"SURVIVE  {Mathf.Max(0, Mathf.CeilToInt(dayEndsAt - runTime))}s";
        }


        private void TrackJourneyDistance(TinyWaveSurfer player)
        {
            float currentX = player.transform.position.x;

            // Freeze distance only for finales that use a locked combat arena.
            // Days 3 and 4 are travel finales, so freezing them here would make
            // their facility/island destinations impossible to reach.
            // Reset the sample while locked so arena movement is not added in one
            // large burst after the encounter ends.
            bool finalWaveUsesLockedArena = currentDay <= 2 || currentDay == 5;
            if (chapter == Chapter.FinalWave && finalWaveUsesLockedArena &&
                !bossDefeatedSunset)
            {
                previousPlayerX = currentX;
                hasPreviousPlayerX = true;
                return;
            }

            if (!hasPreviousPlayerX)
            {
                previousPlayerX = currentX;
                hasPreviousPlayerX = true;
                return;
            }

            float delta = Mathf.Abs(currentX - previousPlayerX);
            previousPlayerX = currentX;
            if (delta < distanceDeadZone || delta > teleportRejectDistance)
                return;

            distanceTravelled += delta;
        }

        private Chapter GetNextChapter(Chapter value)
        {
            return value switch
            {
                Chapter.Dawn => Chapter.FirstRescue,
                Chapter.FirstRescue => Chapter.DangerousWater,
                Chapter.DangerousWater => Chapter.StrangeTide,
                Chapter.StrangeTide => Chapter.Storm,
                Chapter.Storm => Chapter.FinalWave,
                _ => Chapter.Complete
            };
        }

        private float GetDistanceThresholdForChapter(Chapter value)
        {
            float baseThreshold = value switch
            {
                Chapter.FirstRescue => rescueDistance,
                Chapter.DangerousWater => dangerDistance,
                Chapter.StrangeTide => strangeTideDistance,
                Chapter.Storm => stormDistance,
                Chapter.FinalWave => finalWaveDistance,
                Chapter.Complete => dayEndDistance,
                _ => 0f
            };

            if (baseThreshold <= 0f)
                return 0f;

            float baselineEnd = Mathf.Max(1f, dayEndDistance);
            return baseThreshold * (GetDayEndDistance(currentDay) / baselineEnd);
        }

        private float GetDayEndDistance(int day)
        {
            return day switch
            {
                1 => Mathf.Max(60f, dayEndDistance),
                2 => Mathf.Max(60f, dayTwoEndDistance),
                3 => Mathf.Max(60f, dayThreeEndDistance),
                4 => Mathf.Max(60f, dayFourEndDistance),
                5 => Mathf.Max(60f, dayFiveEndDistance),
                _ => Mathf.Max(60f, sandboxDayEndDistance)
            };
        }

        private void PrepareBossArenaSeaLife()
        {
            // The boss is the focus of Final Wave. Stop new sea hazards and make
            // every ordinary sea creature leave the camera before the fight settles.
            StopHostileSpawners();
            RetreatAllHostileSeaCreatures();
        }

        private IEnumerator BuildBossEncounter(
            bool rebuildExisting,
            bool grantCompleteDeveloperLoadout,
            bool showReadyBanner,
            bool saveWhenReady)
        {
            BoomboxSurferSpawner.RestoreForStage(
                currentDay,
                Chapter.FinalWave,
                showHudNotice: grantCompleteDeveloperLoadout);

            // Always yield once so callers can safely store the returned Coroutine
            // before any fast path (notably Day 3) completes.
            yield return null;

            if (grantCompleteDeveloperLoadout)
                SurfAbilityProgression.Instance?.DebugPrepareCompleteBossLoadout();
            else
                SurfAbilityProgression.Instance?.EnsureForStage(currentDay, Chapter.FinalWave);

            chapter = Chapter.FinalWave;
            finalWaveStarted = true;
            bossDefeatedSunset = false;
            changingDay = false;
            runTime = Mathf.Max(runTime, finalWaveBeginsAt + 0.05f);
            distanceTravelled = Mathf.Max(
                distanceTravelled,
                GetDistanceThresholdForChapter(Chapter.FinalWave) + 0.05f);

            RefreshLearningObjectiveForStage();
            SyncDayNightToRunTime();
            PrepareBossArenaSeaLife();

            if (rebuildExisting)
            {
                DestroyAll<BossArenaPrison>();
                DestroyAll<GodzillaLaneSwimmer>();
                DestroyAll<RubberDuckBossSwimmer>();
                DestroyAll<GodzillaSkullSwimmer>();
                DestroyAll<RubberDucklingSwimmer>();
                DestroyAll<GodzillaLaneSpawner>();
                DestroyAll<RubberDuckBossSpawner>();
                DestroyAll<DayFiveCombatant>();
                DestroyAll<DayFiveWardenMissile>();
                DestroyAll<DayFiveSecurityPulse>();
                DestroyAll<DayFiveSecurityImpact>();

                yield return null;
                yield return new WaitForEndOfFrame();
                yield return null;
            }

            if (currentDay == 5)
            {
                DayFiveEncounter encounter = DayFiveEncounter.Begin(this);
                encounter?.SpawnFinalPair();
                FinishBossEncounterBuild(showReadyBanner, saveWhenReady);
                yield break;
            }

            // Day 3 uses the Shadow Surfer. Day 4 is an environmental pursuit
            // toward the research island and deliberately has no giant boss.
            if (currentDay >= 3)
            {
                if (currentDay == 3)
                {
                    DayThreeOceanRemembers dayThree =
                        FindFirstObjectByType<DayThreeOceanRemembers>();

                    if (dayThree == null)
                    {
                        GameObject host = new GameObject("Day Three Ocean Remembers");
                        dayThree = host.AddComponent<DayThreeOceanRemembers>();
                    }
                }

                FinishBossEncounterBuild(showReadyBanner, saveWhenReady);
                yield break;
            }

            float deadline = Time.realtimeSinceStartup + 6f;

            if (currentDay == 1)
            {
                RubberDuckBossSwimmer wrongDuck =
                    FindFirstObjectByType<RubberDuckBossSwimmer>();
                if (wrongDuck != null)
                    Destroy(wrongDuck.gameObject);

                GodzillaLaneSwimmer boss =
                    FindFirstObjectByType<GodzillaLaneSwimmer>();

                if (boss == null)
                {
                    SpawnMajor<GodzillaLaneSpawner>(
                        rebuildExisting ? "Developer Final Godzilla" : "Final Godzilla",
                        spawner => spawner.SpawnGodzilla());
                }

                while (boss == null && Time.realtimeSinceStartup < deadline)
                {
                    yield return null;
                    boss = FindFirstObjectByType<GodzillaLaneSwimmer>();
                }

                if (boss == null)
                {
                    Debug.LogError("Boss encounter failed: Godzilla was not created.", this);
                    pendingBossEncounter = null;
                    yield break;
                }

                yield return EnsureArenaForBoss(
                    boss,
                    BossArenaPrison.ArenaTheme.Reaper,
                    "Reaper Boss Arena Prison");
            }
            else
            {
                GodzillaLaneSwimmer wrongGodzilla =
                    FindFirstObjectByType<GodzillaLaneSwimmer>();
                if (wrongGodzilla != null)
                    Destroy(wrongGodzilla.gameObject);

                RubberDuckBossSwimmer boss =
                    FindFirstObjectByType<RubberDuckBossSwimmer>();

                if (boss == null)
                {
                    SpawnMajor<RubberDuckBossSpawner>(
                        rebuildExisting
                            ? "Developer Day 2 Giant Rubber Duck Boss"
                            : "Day 2 Giant Rubber Duck Boss",
                        spawner => spawner.SpawnRubberDuckBoss());
                }

                // RubberDuckBossSpawner intentionally waits for player, camera, and
                // water readiness, so this path must wait for the swimmer rather
                // than checking only one frame after requesting the spawn.
                while (boss == null && Time.realtimeSinceStartup < deadline)
                {
                    yield return null;
                    boss = FindFirstObjectByType<RubberDuckBossSwimmer>();
                }

                if (boss == null)
                {
                    Debug.LogError(
                        "Boss encounter failed: the Giant Rubber Duck was not created before timeout.",
                        this);
                    pendingBossEncounter = null;
                    yield break;
                }

                yield return EnsureArenaForBoss(
                    boss,
                    BossArenaPrison.ArenaTheme.RubberDuck,
                    "Rubber Duck Boss Arena Prison");
            }

            FinishBossEncounterBuild(showReadyBanner, saveWhenReady);
        }

        private IEnumerator EnsureArenaForBoss(
            MonoBehaviour boss,
            BossArenaPrison.ArenaTheme theme,
            string arenaName)
        {
            // Give the boss spawner one frame to create its own arena first.
            yield return null;

            BossArenaPrison arena = BossArenaPrison.Active;
            if (arena == null)
                arena = FindFirstObjectByType<BossArenaPrison>();

            if (arena == null)
            {
                GameObject arenaHost = new GameObject(arenaName);
                arena = arenaHost.AddComponent<BossArenaPrison>();
            }

            // Merely finding an arena is not enough: a stale arena can be bound to
            // a previous boss and leave the new duck stranded beyond its walls.
            if (!arena.ControlsBoss(boss))
                arena.Configure(boss, theme);
        }

        private void FinishBossEncounterBuild(
            bool showReadyBanner,
            bool saveWhenReady)
        {
            SurfAbilityProgression.Instance?.ApplyUpgradesToAllPlayers();

            if (showReadyBanner)
            {
                ShowBanner(
                    currentDay <= 2 ? "BOSS ENCOUNTER READY" : "FINAL WAVE READY",
                    CurrentObjective,
                    3.5f);
            }

            if (saveWhenReady)
                SurfStageSaveSystem.Save(this);

            pendingBossEncounter = null;
        }

        public void OnFinalBossDefeated()
        {
            if (bossDefeatedSunset || chapter != Chapter.FinalWave)
                return;

            bossDefeatedSunset = true;
            StopHostileSpawners();
            RetreatAllHostileSeaCreatures();

            // The Day 1 UFO must not survive the boss transition into Day 2.
            // Remove every active or disabled instance as soon as the boss ends.
            DestroyAll<AlienUfoController>();

            rain?.ClearRain();

            float shortenedStart = Mathf.Max(0f, dayEndsAt - acceleratedSunsetSeconds);
            runTime = Mathf.Max(runTime, shortenedStart);
            SyncDayNightToRunTime();
            objective = $"SUNSET RUN  {Mathf.Max(0, Mathf.CeilToInt(DayDistance - distanceTravelled))} m";
            ShowBanner("THE DEEP RETREATS", "THE OCEAN GROWS QUIET AS SUNSET FALLS.", 5f);
            QueueCheckpoint();
        }

        /// <summary>
        /// Final chapters are entered before their runtime objects finish spawning.
        /// If an object or arena fails to appear (or is removed after a load), the
        /// chapter would otherwise have no transition capable of rebuilding it.
        /// </summary>
        private void RecoverMissingFinalEncounter(TinyWaveSurfer player)
        {
            if (player == null || chapter != Chapter.FinalWave)
                return;

            if (currentDay == 1 || currentDay == 2)
            {
                MonoBehaviour boss;
                if (currentDay == 1)
                    boss = FindFirstObjectByType<GodzillaLaneSwimmer>();
                else
                    boss = FindFirstObjectByType<RubberDuckBossSwimmer>();
                BossArenaPrison arena = BossArenaPrison.Active != null
                    ? BossArenaPrison.Active
                    : FindFirstObjectByType<BossArenaPrison>();
                bool encounterReady = boss != null && arena != null &&
                    arena.ControlsBoss(boss);

                if (!bossDefeatedSunset && !encounterReady &&
                    pendingBossEncounter == null)
                {
                    pendingBossEncounter = StartCoroutine(
                        BuildBossEncounter(
                            rebuildExisting: false,
                            grantCompleteDeveloperLoadout: false,
                            showReadyBanner: false,
                            saveWhenReady: true));
                }
                return;
            }

            if (currentDay == 3)
            {
                if (distanceTravelled >= GetDistanceThresholdForChapter(Chapter.Complete) ||
                    runTime >= dayEndsAt)
                    EnsureDayThreeFacility(player);
                return;
            }

            if (currentDay == 4)
            {
                DayFourConspiracyEncounter.Begin(this, player);
                return;
            }

            if (currentDay == 5)
                DayFiveEncounter.Begin(this)?.SpawnFinalPair();
        }

        private void EnsureDayThreeFacility(TinyWaveSurfer player)
        {
            if (Time.unscaledTime < nextFacilitySpawnAttemptAt)
                return;

            nextFacilitySpawnAttemptAt = Time.unscaledTime + 1.5f;
            SecretFacilityEncounter facility =
                SecretFacilityEncounter.Begin(this, player);
            if (facility == null)
            {
                facilityEncounterStarted = false;
                return;
            }

            if (facilityEncounterStarted)
                return;

            facilityEncounterStarted = true;
            objective = "FOLLOW THE LIGHTS ON THE HORIZON";
            learningObjective = string.Empty;
            banner = "SOMETHING IS OUT THERE";
            bannerUntil = Time.unscaledTime + 4f;
            rain?.ClearRain();
            QueueCheckpoint();
        }

        private void StopHostileSpawners()
        {
            DisableAll<SharkLaneSpawner>();
            DisableAll<GiantSquidLaneSpawner>();
            DisableAll<JellyfishSchoolSpawner>();
            DisableAll<WhaleLaneSpawner>();
            DisableAll<BloodSharkLaneSpawner>();
            DisableAll<TransparentSquidLaneSpawner>();
            DisableAll<StingrayLaneSpawner>();
            DisableAll<BloodfishSchoolSpawner>();
        }

        private static void DisableAll<T>() where T : Behaviour
        {
            foreach (T spawner in FindObjectsByType<T>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                if (spawner != null) spawner.enabled = false;
        }

        private void RetreatAllHostileSeaCreatures()
        {
            BeginRetreat<SharkLaneSwimmer>();
            BeginRetreat<GiantSquidLaneSwimmer>();
            BeginRetreat<JellyfishSwimmer>();
            BeginRetreat<WhaleLaneSwimmer>();
            BeginRetreat<BloodSharkLaneSwimmer>();
            BeginRetreat<TransparentSquidLaneSwimmer>();
            BeginRetreat<StingrayLaneSwimmer>();
            BeginRetreat<BloodfishSwimmer>();
            BeginRetreat<RubberDucklingSwimmer>();
            BeginRetreat<GiantTurtleSwimmer>();
            BeginRetreat<SeaTurtleSwimmer>();
        }

        public void DebugNextChapter()
        {
            Chapter targetChapter = chapter;
            switch (chapter)
            {
                case Chapter.Dawn:
                    targetChapter = Chapter.FirstRescue;
                    runTime = Mathf.Max(runTime, rescueBeginsAt + 0.05f);
                    distanceTravelled = Mathf.Max(distanceTravelled,
                        GetDistanceThresholdForChapter(Chapter.FirstRescue) + 0.05f);
                    break;
                case Chapter.FirstRescue:
                    targetChapter = Chapter.DangerousWater;
                    runTime = Mathf.Max(runTime, dangerBeginsAt + 0.05f);
                    distanceTravelled = Mathf.Max(distanceTravelled,
                        GetDistanceThresholdForChapter(Chapter.DangerousWater) + 0.05f);
                    break;
                case Chapter.DangerousWater:
                    targetChapter = Chapter.StrangeTide;
                    runTime = Mathf.Max(runTime, strangeTideBeginsAt + 0.05f);
                    distanceTravelled = Mathf.Max(distanceTravelled,
                        GetDistanceThresholdForChapter(Chapter.StrangeTide) + 0.05f);
                    break;
                case Chapter.StrangeTide:
                    targetChapter = Chapter.Storm;
                    runTime = Mathf.Max(runTime, stormBeginsAt + 0.05f);
                    distanceTravelled = Mathf.Max(distanceTravelled,
                        GetDistanceThresholdForChapter(Chapter.Storm) + 0.05f);
                    break;
                case Chapter.Storm:
                    targetChapter = Chapter.FinalWave;
                    if (currentDay == 5)
                        DayFiveEncounter.Begin(this)?.DebugAllowFinalWave();
                    runTime = Mathf.Max(runTime, finalWaveBeginsAt + 0.05f);
                    distanceTravelled = Mathf.Max(distanceTravelled,
                        GetDistanceThresholdForChapter(Chapter.FinalWave) + 0.05f);
                    break;
                case Chapter.FinalWave:
                    targetChapter = Chapter.Complete;
                    runTime = Mathf.Max(runTime, dayEndsAt + 0.05f);
                    distanceTravelled = Mathf.Max(distanceTravelled,
                        GetDistanceThresholdForChapter(Chapter.Complete) + 0.05f);
                    break;
            }

            // Apply the destination chapter's mechanics immediately, before the
            // deferred checkpoint is captured. Update() will still perform the
            // normal population/banner transition on the following frame.
            SurfAbilityProgression.Instance?.EnsureForStage(currentDay, targetChapter);
            SyncDayNightToRunTime();
            QueueCheckpoint();
        }

        public void DebugSpawnBoss()
        {
            // DebugNextChapter remains untouched. This button uses the exact same
            // encounter builder as normal progression and save restoration, but
            // requests a clean rebuild and the complete developer combat loadout.
            if (pendingBossEncounter != null)
                return;

            pendingBossEncounter = StartCoroutine(
                BuildBossEncounter(
                    rebuildExisting: true,
                    grantCompleteDeveloperLoadout: true,
                    showReadyBanner: true,
                    saveWhenReady: true));
        }

        public void DebugResetCurrentDay()
        {
            DebugSelectDay(currentDay);
        }

        public void DebugSelectDay(int requestedDay)
        {
            int selectedDay = Mathf.Clamp(requestedDay, 1, 7);

            // A developer selection replaces every active transition. This makes
            // repeated forward/backward jumps deterministic even if another day,
            // checkpoint, boss build, upgrade screen, or storyboard was running.
            StopAllCoroutines();
            pendingCheckpoint = null;
            pendingBossEncounter = null;
            SurfDayUpgradeScreen.Instance?.CancelImmediate();
            StoryboardCutsceneSystem.CancelImmediate();

            developerDaySwitchInProgress = true;
            currentDay = selectedDay;
            chapter = Chapter.Complete;
            changingDay = true;
            facilityEncounterStarted = false;
            finalWaveStarted = false;
            bossDefeatedSunset = false;

            FindFirstObjectByType<DayFiveEncounter>()?.EndEncounter();
            FindFirstObjectByType<DaySixEncounter>()?.EndEncounter();
            rain?.ClearRain();
            SurfRunLifeManager.Instance?.ResetLivesForNewRun();

            StartCoroutine(SwitchToDeveloperDay(selectedDay));
        }

        private IEnumerator SwitchToDeveloperDay(int selectedDay)
        {
            // Zeroed progression fields deliberately use RestoreFor below. Day 1
            // therefore returns to its starting Wave Switch only, while Day 2+
            // receive their normal full core moveset. Later-day abilities can no
            // longer leak backward into a Day 1 test.
            SurfStageSaveSystem.SaveData freshDay = new()
            {
                day = selectedDay,
                chapter = (int)Chapter.Dawn,
                runTime = 0f,
                distanceTravelled = 0f,
                rescues = 0,
                finalWaveStarted = false,
                bossDefeatedSunset = false,
                lives = SurfRunLifeManager.Instance != null
                    ? SurfRunLifeManager.Instance.StartingLives
                    : 3,
                unlockedAbilities = 0,
                jumpUpgradeLevel = 0,
                waterSlashUpgradeLevel = 0,
                skidUpgradeLevel = 0,
                totalStoke = 0,
                dayStoke = 0,
                hasPlayerState = false
            };

            yield return LoadSavedRun(freshDay);

            developerDaySwitchInProgress = false;
            changingDay = false;
            ShowBanner($"DEVELOPER DAY {selectedDay}", "CLEAN DAWN STATE READY.", 3.5f);
            SurfStageSaveSystem.Save(this);
        }

        public void DebugNextDay()
        {
            DebugSelectDay(Mathf.Clamp(currentDay + 1, 1, 7));
        }

        private void BeginRetreat<T>() where T : MonoBehaviour
        {
            foreach (T creature in FindObjectsByType<T>(FindObjectsInactive.Exclude, FindObjectsSortMode.None))
            {
                if (creature == null)
                    continue;

                GameObject creatureObject = creature.gameObject;
                SeaCreatureRetreatMover mover = creatureObject.GetComponent<SeaCreatureRetreatMover>();
                if (mover == null)
                    mover = creatureObject.AddComponent<SeaCreatureRetreatMover>();

                creature.enabled = false;
                mover.Begin(retreatSpeedMultiplier);
            }
        }

        private void UpdateDayOneMechanicUnlocks()
        {
            if (currentDay != 1 || SurfAbilityProgression.Instance == null)
                return;

            if (runTime >= handstandUnlockAt &&
                !SurfAbilityProgression.Instance.Has(SurfAbility.Handstand))
                UnlockAbility(SurfAbility.Handstand,
                    "HANDSTAND UNLOCKED",
                    "PRESS A / SPACE AGAIN WHILE AIRBORNE.");

            if (runTime >= throwingUnlockAt &&
                !SurfAbilityProgression.Instance.Has(SurfAbility.ThrowItems))
                UnlockAbility(SurfAbility.ThrowItems,
                    "THROWING UNLOCKED",
                    "PRESS X / F ON THE WATER TO THROW A COLLECTED OBJECT.");

            if (runTime >= waterSkidUnlockAt &&
                !SurfAbilityProgression.Instance.Has(SurfAbility.WaterSkid))
                UnlockAbility(SurfAbility.WaterSkid,
                    "WATER SKID UNLOCKED",
                    "HOLD B / E ON THE WATER, THEN RELEASE.");

            if (runTime >= waterSlashUnlockAt &&
                !SurfAbilityProgression.Instance.Has(SurfAbility.WaterSlash))
                UnlockAbility(SurfAbility.WaterSlash,
                    "WATER SLASH UNLOCKED",
                    "PRESS RB / R WHILE RIDING.");
        }

        private void OnCleanChainLanded(int chainLength)
        {
            if (currentDay != 1 || chapter < Chapter.StrangeTide || chainLength < 2)
                return;

            UnlockAbility(SurfAbility.Flow,
                "FLOW METER UNLOCKED",
                "CLEAN TRICK CHAINS BUILD FLOW. KEEP THE RHYTHM GOING.");
            RefreshLearningObjectiveForStage();
        }

        private void OnFirstOnFireActivated()
        {
            if (currentDay != 1 || SurfAbilityProgression.Instance == null ||
                !SurfAbilityProgression.Instance.Has(SurfAbility.Flow))
                return;

            UnlockAbility(SurfAbility.FlowFinisher,
                "FLOW FINISHER UNLOCKED",
                "WHILE ON FIRE, PRESS RB / R ON THE WATER.");
            RefreshLearningObjectiveForStage();
        }

        private void OnSwimmerSaved()
        {
            rescues++;
            if (currentDay == 6)
            {
                ShowBanner("HORIZON RECORD RECOVERED", "THE SEVENTH CURRENT IS FARTHER OUT.", 3.5f);
                objective = "FOLLOW THE CREATURES BEYOND THE MAP";
                learningObjective = string.Empty;
                QueueCheckpoint();
                return;
            }

            ShowBanner("SWIMMER SAVED", $"RESCUES  {rescues}/{rescuesRequired}", 2.5f);
            QueueCheckpoint();

            if (rescues < rescuesRequired)
                SpawnRescueSet(1);
            else if (chapter == Chapter.DangerousWater)
                objective = "RESCUES COMPLETE — SURVIVE THE CHANGING TIDE";
        }

        private void BeginChapter(Chapter next, string heading, string newObjective)
        {
            chapter = next;
            objective = newObjective;
            RefreshLearningObjectiveForStage();
            ShowBanner(heading, CurrentObjective, 4f);
            QueueCheckpoint();
        }

        private void UnlockAbility(SurfAbility ability, string heading, string instruction)
        {
            if (SurfAbilityProgression.Instance == null)
                return;

            if (!SurfAbilityProgression.Instance.Unlock(ability))
                return;

            learningObjective = instruction;
            ShowBanner(heading, instruction, 5f);
            SurfStageSaveSystem.Save(this);
        }

        private void RefreshLearningObjectiveForStage()
        {
            SurfAbilityProgression abilities = SurfAbilityProgression.Instance;

            if (currentDay == 6)
            {
                learningObjective = chapter switch
                {
                    Chapter.Dawn => "Watch how the fishbowl ricochets and how the starfish changes lanes.",
                    Chapter.FirstRescue => "The small oddities still obey the inter-wave gaps.",
                    Chapter.DangerousWater => "The shark feints before charging; the toaster fires down a lane.",
                    Chapter.StrangeTide => "Mushroom spores and resort wakes occupy visible lanes.",
                    Chapter.Storm => "The toilet alternates lanes during its Royal Flush volley.",
                    Chapter.FinalWave => "Use wave switches, thrown items and Water Slash against the full roster.",
                    _ => string.Empty
                };
                return;
            }

            if (currentDay == 5)
            {
                learningObjective = chapter switch
                {
                    Chapter.Dawn => "The buoy attacks from the water while the drone patrols overhead.",
                    Chapter.FirstRescue => "Hold Up while throwing to prioritize the drone.",
                    Chapter.DangerousWater => "The drone and buoy share the same wave render lane.",
                    Chapter.StrangeTide => "The buoy's red sky beam locks early; keep moving.",
                    Chapter.Storm => "The signal relay fires angled spectrum beams across the waterline.",
                    Chapter.FinalWave => "The Warden cycles through missiles, crossfire, prism fans, and lock grids.",
                    _ => string.Empty
                };
                return;
            }

            if (currentDay >= 2)
            {
                learningObjective = string.Empty;
                return;
            }

            if (chapter == Chapter.Dawn)
            {
                learningObjective = "Surf left/right. Hold Up/Down + Jump to change waves.";
                return;
            }

            if (chapter == Chapter.FirstRescue)
            {
                learningObjective = "Reach struggling swimmers. A rescue restores 1 life.";
                return;
            }

            if (abilities == null || !abilities.Has(SurfAbility.ChargedJump))
                learningObjective = "Hold Jump while moving, then release to launch.";
            else if (!abilities.Has(SurfAbility.Handstand))
                learningObjective = "Press A / Space again while airborne for a handstand.";
            else if (!abilities.Has(SurfAbility.ThrowItems))
                learningObjective = "Press X / F on the water to throw a collected object.";
            else if (!abilities.Has(SurfAbility.TripleChain))
                learningObjective = "Chain different air tricks before landing.";
            else if (!abilities.Has(SurfAbility.Flow))
                learningObjective = "Land a clean multi-trick chain to reveal Flow.";
            else if (!abilities.Has(SurfAbility.WaterSkid))
                learningObjective = "Clean chains build Flow. Keep the rhythm going.";
            else if (!abilities.Has(SurfAbility.WaterSlash))
                learningObjective = "Hold B / E on the water, then release for a skid.";
            else if (!abilities.Has(SurfAbility.FlowFinisher))
                learningObjective = "Build Flow to 100% and enter ON FIRE.";
            else if (chapter >= Chapter.FinalWave)
                learningObjective = "Tip • Build Flow and use the finisher against the boss.";
            else
                learningObjective = "While ON FIRE, press RB / R on the water for Flow Finisher.";
        }

        private void ShowBanner(string heading, string subheading, float duration)
        {
            banner = heading + "\n" + subheading;
            bannerUntil = Time.unscaledTime + duration;
        }

        private void SpawnPickupSet()
        {
            foreach (float centre in GetCentres())
            {
                SpawnAt<SodaCanSpawner>("Progression Soda Can", centre, s => s.SpawnCan());
                SpawnAt<HeartLaneSpawner>("Progression Heart", centre, s => s.SpawnHeart());
            }
        }

        private void SpawnRescueSet(int count)
        {
            IReadOnlyList<float> centres = GetCentres();
            if (centres.Count == 0) return;
            for (int i = 0; i < count; i++)
            {
                float x = centres[Random.Range(0, centres.Count)];
                SpawnAt<StrugglingSwimmerSpawner>("Story Rescue", x, s => s.SpawnSwimmer());
            }
        }

        private void SpawnMajor<T>(string name, System.Action<T> spawn) where T : Component
        {
            IReadOnlyList<float> centres = GetCentres();
            float x = centres.Count > 0 ? centres[Random.Range(0, centres.Count)] : 0f;
            SpawnAt(name, x, spawn);
        }

        private void SpawnAt<T>(string name, float x, System.Action<T> spawn) where T : Component
        {
            GameObject holder = new(name);
            holder.transform.SetParent(transform, false);
            holder.transform.position = new Vector3(x, 0f, 0f);
            T component = holder.AddComponent<T>();
            if (component is Behaviour behaviour) behaviour.enabled = true;
            spawn(component);
            progressionSpawners.Add(holder);
        }


        private void SpawnOceanItems(int count)
        {
            if (FindFirstObjectByType<OceanItemSpawner>() is OceanItemSpawner existing)
            {
                existing.SpawnProgressionItems(count);
                return;
            }

            GameObject holder = new("Progression Ocean Items");
            holder.transform.SetParent(transform, false);
            OceanItemSpawner spawner = holder.AddComponent<OceanItemSpawner>();
            spawner.SpawnProgressionItems(count);
            progressionSpawners.Add(holder);
        }

        private void SpawnJellyfishEncounter(string name, int schools)
        {
            IReadOnlyList<float> centres = GetCentres();
            if (centres.Count == 0) return;

            for (int i = 0; i < schools; i++)
            {
                float x = centres[(i + Random.Range(0, centres.Count)) % centres.Count];
                IReadOnlyList<PixelWaterGPU> layers = EndlessWaveSections.LayersNearest(x);
                x = CameraSafeSpawnUtility.ChooseOffscreenEntryX(layers, null, out _);
                GameObject holder = new(name + " " + (i + 1));
                holder.transform.SetParent(transform, false);
                holder.transform.position = new Vector3(x, 0f, 0f);
                JellyfishSchoolSpawner spawner = holder.AddComponent<JellyfishSchoolSpawner>();
                spawner.SpawnSchool();
                progressionSpawners.Add(holder);
            }
        }

        private void SpawnBloodfishEncounter(string name, int schools)
        {
            IReadOnlyList<float> centres = GetCentres();
            if (centres.Count == 0) return;

            for (int i = 0; i < schools; i++)
            {
                float x = centres[(i + Random.Range(0, centres.Count)) % centres.Count];
                IReadOnlyList<PixelWaterGPU> layers = EndlessWaveSections.LayersNearest(x);
                x = CameraSafeSpawnUtility.ChooseOffscreenEntryX(layers, null, out _);
                GameObject holder = new(name + " " + (i + 1));
                holder.transform.SetParent(transform, false);
                holder.transform.position = new Vector3(x, 0f, 0f);
                BloodfishSchoolSpawner spawner = holder.AddComponent<BloodfishSchoolSpawner>();
                spawner.SpawnSchool();
                progressionSpawners.Add(holder);
            }
        }

        private void SpawnBoombox()
        {
            // Strange Tide unlocks the player-controlled board summon.
            // The board itself appears only when the player presses LB / M.
            BoomboxSurferSpawner.RestoreForStage(
                currentDay,
                chapter,
                showHudNotice: currentDay == 1);
        }

        private void SpawnUfo()
        {
            if (FindFirstObjectByType<AlienUfoController>() != null) return;
            GameObject ufo = new("Alien UFO - Story Encounter");
            ufo.AddComponent<SpriteRenderer>();
            ufo.AddComponent<AlienUfoController>();
        }

        private void SpawnHelicopter()
        {
            if (FindFirstObjectByType<DayTwoHelicopterController>() != null) return;
            GameObject holder = new("Day 2 Helicopter Encounter");
            holder.transform.SetParent(transform, false);
            DayTwoHelicopterSpawner spawner = holder.AddComponent<DayTwoHelicopterSpawner>();
            spawner.SpawnHelicopter();
            progressionSpawners.Add(holder);
        }

        private ProceduralRainSystem EnsureRain()
        {
            if (rain != null) return rain;
            rain = FindFirstObjectByType<ProceduralRainSystem>();
            if (rain == null)
                rain = new GameObject("Progression Rain").AddComponent<ProceduralRainSystem>();
            return rain;
        }

        private static IReadOnlyList<float> GetCentres()
        {
            return EndlessWaveSections.Instance != null
                ? EndlessWaveSections.Instance.GetSectionCentres()
                : System.Array.Empty<float>();
        }

        // Progression presentation is handled by SurferSlugMinimalHud so every
        // gameplay HUD element shares one Canvas, layout and visual style.
    }
}
